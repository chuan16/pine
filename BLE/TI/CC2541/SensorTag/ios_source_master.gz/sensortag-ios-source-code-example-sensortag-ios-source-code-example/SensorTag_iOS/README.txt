10/26/2015

This application needs the MQTTKit framework located at :

https://github.com/jmesnil/MQTTKit.git


Install steps :


1. Make directory SensorTag2-Example
2. Enter directory and unzip SensorTag2-Example.zip here
3. Make Directory MQTT and enter it.
4. Run : git clone https://github.com/jmesnil/MQTTKit.git
5. Open SensorTag-Example.xcodeproj in Xcode.
6. Compile.



