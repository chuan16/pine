BleActionLog
============

Example Android app that connects to Bluetooth Low Energy devices logging the actions that occur.
