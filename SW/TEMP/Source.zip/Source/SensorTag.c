/******************************************************************************

 @file  SensorTag.c

 @brief This file contains the Sensor Tag sample application for use with the
        TI Bluetooth Low Energy Protocol Stack.

 Group: WCS, BTS
 Target Device: CC2540, CC2541

 ******************************************************************************

 Copyright (c) 2012-2016, Texas Instruments Incorporated
 All rights reserved.

 IMPORTANT: Your use of this Software is limited to those specific rights
 granted under the terms of a software license agreement between the user
 who downloaded the software, his/her employer (which must be your employer)
 and Texas Instruments Incorporated (the "License"). You may not use this
 Software unless you agree to abide by the terms of the License. The License
 limits your use, and you acknowledge, that the Software may not be modified,
 copied or distributed unless embedded on a Texas Instruments microcontroller
 or used solely and exclusively in conjunction with a Texas Instruments radio
 frequency transceiver, which is integrated into your product. Other than for
 the foregoing purpose, you may not use, reproduce, copy, prepare derivative
 works of, modify, distribute, perform, display or sell this Software and/or
 its documentation for any purpose.

 YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
 PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
 NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
 TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
 NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
 LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
 INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
 OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
 OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
 (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

 Should you have any questions regarding your right to use this Software,
 contact Texas Instruments Incorporated at www.TI.com.

 ******************************************************************************
 Release Name: ble_sdk_1.4.2.2
 Release Date: 2016-06-09 06:57:10
 *****************************************************************************/

/*********************************************************************
 * INCLUDES
 */

#include "bcomdef.h"
#include "OSAL.h"
#include "OSAL_PwrMgr.h"

#include "OnBoard.h"
#include "hal_adc.h"
#include "hal_led.h"
#include "hal_keys.h"
#include "hal_i2c.h"

#include "gatt.h"
#include "hci.h"

#include "gapgattserver.h"
#include "gattservapp.h"

#if defined ( PLUS_BROADCASTER )
#include "peripheralBroadcaster.h"
#else
#include "peripheral.h"
#endif

#include "gapbondmgr.h"

#if defined FEATURE_OAD
#include "oad.h"
#include "oad_target.h"
#endif

// Services
#include "st_util.h"
#include "devinfoservice-st.h"
/*#include "irtempservice.h"*/
#include "accelerometerservice.h"
/*#include "humidityservice.h"
#include "magnetometerservice.h"
#include "barometerservice.h"
#include "gyroservice.h"*/
#if defined FEATURE_TEST
#include "testservice.h"
#endif
#include "simplekeys.h"
#include "ccservice.h"

// Sensor drivers
#include "sensorTag.h"
///TODO: check if we can remove "hal_sensor.h"
//#include "hal_sensor.h"  

/*#include "hal_irtemp.h"*/
#include "hal_acc_stm.h"
/*#include "hal_humi.h"
#include "hal_mag.h"
#include "hal_bar.h"
#include "hal_gyro.h"*/

/*********************************************************************
 * MACROS
 */

/*********************************************************************
 * CONSTANTS
 */

// How often to perform sensor reads (milliseconds)
/*
#define TEMP_DEFAULT_PERIOD                   1000
#define HUM_DEFAULT_PERIOD                    1000
#define BAR_DEFAULT_PERIOD                    1000
#define MAG_DEFAULT_PERIOD                    2000
*/
#define ACC_DEFAULT_PERIOD                    1000
/*
#define GYRO_DEFAULT_PERIOD                   1000
*/
// Constants for two-stage reading
/*#define TEMP_MEAS_DELAY                       275   // Conversion time 250 ms
#define BAR_FSM_PERIOD                        80*/
#define ACC_FSM_PERIOD                        20
/*#define HUM_FSM_PERIOD                        20
#define GYRO_STARTUP_TIME                     60    // Start-up time max. 50 ms*/

// What is the advertising interval when device is discoverable (units of 625us, 160=100ms)
#define DEFAULT_ADVERTISING_INTERVAL          160

// General discoverable mode advertises indefinitely
#define DEFAULT_DISCOVERABLE_MODE             GAP_ADTYPE_FLAGS_LIMITED

// Minimum connection interval (units of 1.25ms, 80=100ms) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_MIN_CONN_INTERVAL     80

// Maximum connection interval (units of 1.25ms, 800=1000ms) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_MAX_CONN_INTERVAL     800

// Slave latency to use if automatic parameter update request is enabled
#define DEFAULT_DESIRED_SLAVE_LATENCY         0

// Supervision timeout value (units of 10ms, 1000=10s) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_CONN_TIMEOUT          1000

// Whether to enable automatic parameter update request when a connection is formed
#define DEFAULT_ENABLE_UPDATE_REQUEST         FALSE

// Connection Pause Peripheral time value (in seconds)
#define DEFAULT_CONN_PAUSE_PERIPHERAL         8

// Company Identifier: Texas Instruments Inc. (13)
/*#define TI_COMPANY_ID                         0x000D*/

#define INVALID_CONNHANDLE                    0xFFFF

// Length of bd addr as a string
#define B_ADDR_STR_LEN                        15

#if defined ( PLUS_BROADCASTER )
#define ADV_IN_CONN_WAIT                    500 // delay 500 ms
#endif

// Side key bit
#define SK_KEY_SIDE                           0x04

// Test mode bit
#define TEST_MODE_ENABLE                      0x80

// Common values for turning a sensor on and off + config/status
#define ST_CFG_SENSOR_DISABLE                 0x00
#define ST_CFG_SENSOR_ENABLE                  0x01
#define ST_CFG_CALIBRATE                      0x02
#define ST_CFG_ERROR                          0xFF

// System reset
#define ST_SYS_RESET_DELAY                    3000

/*********************************************************************
 * TYPEDEFS
 */

/*********************************************************************
 * GLOBAL VARIABLES
 */

/*********************************************************************
 * EXTERNAL VARIABLES
 */

/*********************************************************************
 * EXTERNAL FUNCTIONS
 */

/*********************************************************************
 * LOCAL VARIABLES
 */
/*
static uint8 sensorTag_TaskID;   // Task ID for internal task/event processing
*/
static uint8 pine_TaskID;   // Task ID for internal task/event processing

static gaprole_States_t gapProfileState = GAPROLE_INIT;

// GAP - SCAN RSP data (max size = 31 bytes)
static uint8 scanRspData[] = {
    // complete name
    0x05,   // length of this data
    GAP_ADTYPE_LOCAL_NAME_COMPLETE,
    0x50,   // 'P'
    0x69,   // 'i'
    0x6E,   // 'n'
    0x65,   // 'e'

    // connection interval range
    0x05,   // length of this data
    GAP_ADTYPE_SLAVE_CONN_INTERVAL_RANGE,
    LO_UINT16( DEFAULT_DESIRED_MIN_CONN_INTERVAL ),
    HI_UINT16( DEFAULT_DESIRED_MIN_CONN_INTERVAL ),
    LO_UINT16( DEFAULT_DESIRED_MAX_CONN_INTERVAL ),
    HI_UINT16( DEFAULT_DESIRED_MAX_CONN_INTERVAL ),

    // Tx power level
    0x02,   // length of this data
    GAP_ADTYPE_POWER_LEVEL,
    0       // 0dBm
};

// GAP - Advertisement data (max size = 31 bytes, though this is
// best kept short to conserve power while advertisting)
static uint8 advertData[] = {
    // Flags; this sets the device to use limited discoverable
    // mode (advertises for 30 seconds at a time) instead of general
    // discoverable mode (advertises indefinitely)
    0x02,   // length of this data
    GAP_ADTYPE_FLAGS,
    DEFAULT_DISCOVERABLE_MODE | GAP_ADTYPE_FLAGS_BREDR_NOT_SUPPORTED
};

// GAP GATT Attributes

static uint8 attDeviceName[] = "Pine BLE";

// Sensor State Variables
static uint8  accConfig = ST_CFG_SENSOR_DISABLE;

static bool   sysResetRequest = FALSE;

static uint16 sensorAccPeriod = ACC_DEFAULT_PERIOD;
static bool   testMode = FALSE;

/*********************************************************************
 * LOCAL FUNCTIONS
 */
static void sensorTag_ProcessOSALMsg( osal_event_hdr_t *pMsg );
static void peripheralStateNotificationCB( gaprole_States_t newState );

static void readAccData( void );

static void accelChangeCB( uint8 paramID );
#if defined FEATURE_TEST
static void testChangeCB( uint8 paramID );
#endif
static void ccChangeCB( uint8 paramID );
static void ccUpdate( void );
static void gapRolesParamUpdateCB( uint16 connInterval, uint16 connSlaveLatency,
                                   uint16 connTimeout );

static void resetSensorSetup( void );
static void sensorTag_HandleKeys( uint8 shift, uint8 keys );
static void resetCharacteristicValue( uint16 servID, uint8 paramID, uint8 value,
                                      uint8 paramLen );
static void resetCharacteristicValues( void );

/*********************************************************************
 * PROFILE CALLBACKS
 */

// GAP Role Callbacks
static gapRolesCBs_t sensorTag_PeripheralCBs = {
    peripheralStateNotificationCB,  // Profile State Change Callbacks
    NULL                            // When a valid RSSI is read from controller (not used by application)
};

// GAP Bond Manager Callbacks
static gapBondCBs_t sensorTag_BondMgrCBs = {
    NULL,                     // Passcode callback (not used by application)
    NULL                      // Pairing / Bonding state Callback (not used by application)
};

// Simple GATT Profile Callbacks

static sensorCBs_t sensorTag_AccelCBs = {
    accelChangeCB,            // Characteristic value change callback
};

#if defined FEATURE_TEST
static testCBs_t sensorTag_TestCBs = {
    testChangeCB,             // Characteristic value change callback
};
#endif

static ccCBs_t sensorTag_ccCBs = {
    ccChangeCB,               // Characteristic value change callback
};

static gapRolesParamUpdateCB_t paramUpdateCB = {
    gapRolesParamUpdateCB,
};

/*********************************************************************
 * PUBLIC FUNCTIONS
 */

/*********************************************************************
 * @fn      SensorTag_Init
 *
 * @brief   Initialization function for the Simple BLE Peripheral App Task.
 *          This is called during initialization and should contain
 *          any application specific initialization (ie. hardware
 *          initialization/setup, table initialization, power up
 *          notification ... ).
 *
 * @param   task_id - the ID assigned by OSAL.  This ID should be
 *                    used to send messages and set timers.
 *
 * @return  none
 */
void SensorTag_Init( uint8 task_id )
{
    pine_TaskID = task_id;

    // Setup the GAP
    VOID GAP_SetParamValue( TGAP_CONN_PAUSE_PERIPHERAL, DEFAULT_CONN_PAUSE_PERIPHERAL );

    // Setup the GAP Peripheral Role Profile
    {
        // Device starts advertising upon initialization
        uint8 initial_advertising_enable = FALSE;

        // By setting this to zero, the device will go into the waiting state after
        // being discoverable for 30.72 second, and will not being advertising again
        // until the enabler is set back to TRUE
        uint16 gapRole_AdvertOffTime = 0;
        uint8 enable_update_request = DEFAULT_ENABLE_UPDATE_REQUEST;
        uint16 desired_min_interval = DEFAULT_DESIRED_MIN_CONN_INTERVAL;
        uint16 desired_max_interval = DEFAULT_DESIRED_MAX_CONN_INTERVAL;
        uint16 desired_slave_latency = DEFAULT_DESIRED_SLAVE_LATENCY;
        uint16 desired_conn_timeout = DEFAULT_DESIRED_CONN_TIMEOUT;

        // Set the GAP Role Parameters
        GAPRole_SetParameter( GAPROLE_ADVERT_ENABLED, sizeof( uint8 ), &initial_advertising_enable );
        GAPRole_SetParameter( GAPROLE_ADVERT_OFF_TIME, sizeof( uint16 ), &gapRole_AdvertOffTime );

        GAPRole_SetParameter( GAPROLE_SCAN_RSP_DATA, sizeof ( scanRspData ), scanRspData );
        GAPRole_SetParameter( GAPROLE_ADVERT_DATA, sizeof( advertData ), advertData );

        GAPRole_SetParameter( GAPROLE_PARAM_UPDATE_ENABLE, sizeof( uint8 ), &enable_update_request );
        GAPRole_SetParameter( GAPROLE_MIN_CONN_INTERVAL, sizeof( uint16 ), &desired_min_interval );
        GAPRole_SetParameter( GAPROLE_MAX_CONN_INTERVAL, sizeof( uint16 ), &desired_max_interval );
        GAPRole_SetParameter( GAPROLE_SLAVE_LATENCY, sizeof( uint16 ), &desired_slave_latency );
        GAPRole_SetParameter( GAPROLE_TIMEOUT_MULTIPLIER, sizeof( uint16 ), &desired_conn_timeout );
    }

    // Set the GAP Characteristics
    GGS_SetParameter( GGS_DEVICE_NAME_ATT, sizeof(attDeviceName), attDeviceName );

    // Set advertising interval
    {
        uint16 advInt = DEFAULT_ADVERTISING_INTERVAL;

        GAP_SetParamValue( TGAP_LIM_DISC_ADV_INT_MIN, advInt );
        GAP_SetParamValue( TGAP_LIM_DISC_ADV_INT_MAX, advInt );
        GAP_SetParamValue( TGAP_GEN_DISC_ADV_INT_MIN, advInt );
        GAP_SetParamValue( TGAP_GEN_DISC_ADV_INT_MAX, advInt );
    }

    // Setup the GAP Bond Manager
    {
        uint32 passkey = 0; // passkey "000000"
        uint8 pairMode = GAPBOND_PAIRING_MODE_WAIT_FOR_REQ;
        uint8 mitm = TRUE;
        uint8 ioCap = GAPBOND_IO_CAP_DISPLAY_ONLY;
        uint8 bonding = TRUE;

        GAPBondMgr_SetParameter( GAPBOND_DEFAULT_PASSCODE, sizeof ( uint32 ), &passkey );
        GAPBondMgr_SetParameter( GAPBOND_PAIRING_MODE, sizeof ( uint8 ), &pairMode );
        GAPBondMgr_SetParameter( GAPBOND_MITM_PROTECTION, sizeof ( uint8 ), &mitm );
        GAPBondMgr_SetParameter( GAPBOND_IO_CAPABILITIES, sizeof ( uint8 ), &ioCap );
        GAPBondMgr_SetParameter( GAPBOND_BONDING_ENABLED, sizeof ( uint8 ), &bonding );
    }


    // Add services
    GGS_AddService( GATT_ALL_SERVICES );            // GAP
    GATTServApp_AddService( GATT_ALL_SERVICES );    // GATT attributes
    DevInfo_AddService();                           // Device Information Service
    Accel_AddService();                             // Accelerometer Service
    SK_AddService( GATT_ALL_SERVICES );             // Simple Keys Profile
#if defined FEATURE_TEST
    Test_AddService();                              // Test Profile
#endif
    CcService_AddService();                         // Connection Control Service

#if defined FEATURE_OAD
    VOID OADTarget_AddService();                    // OAD Profile
#endif

    // Setup the Sensor Profile Characteristic Values
    resetCharacteristicValues();

    // Register for all key events - This app will handle all key events
    RegisterForKeys( pine_TaskID );

    // makes sure LEDs are off
    //HalLedSet( (HAL_LED_1 | HAL_LED_2), HAL_LED_MODE_OFF );

    // Initialize sensor drivers
    hal_acc_init();

    // Register callbacks with profile
    VOID Accel_RegisterAppCBs( &sensorTag_AccelCBs );
#if defined FEATURE_TEST
    VOID Test_RegisterAppCBs( &sensorTag_TestCBs );
#endif
    VOID CcService_RegisterAppCBs( &sensorTag_ccCBs );
    VOID GAPRole_RegisterAppCBs( &paramUpdateCB );

    // Enable clock divide on halt
    // This reduces active current while radio is active and CC254x MCU
    // is halted
    HCI_EXT_ClkDivOnHaltCmd( HCI_EXT_ENABLE_CLK_DIVIDE_ON_HALT );

    // Setup a delayed profile startup
    osal_set_event( pine_TaskID, ST_START_DEVICE_EVT );
}

/*********************************************************************
 * @fn      SensorTag_ProcessEvent
 *
 * @brief   Simple BLE Peripheral Application Task event processor.  This function
 *          is called to process all events for the task.  Events
 *          include timers, messages and any other user defined events.
 *
 * @param   task_id  - The OSAL assigned task ID.
 * @param   events - events to process.  This is a bit map and can
 *                   contain more than one event.
 *
 * @return  events not processed
 */
uint16 SensorTag_ProcessEvent( uint8 task_id, uint16 events )
{
    VOID task_id; // OSAL required parameter that is not used in this function

    if ( events & SYS_EVENT_MSG ) {
        uint8 *pMsg;

        if ( (pMsg = osal_msg_receive( pine_TaskID )) != NULL ) {
            sensorTag_ProcessOSALMsg( (osal_event_hdr_t *)pMsg );

            // Release the OSAL message
            VOID osal_msg_deallocate( pMsg );
        }

        // return unprocessed events
        return (events ^ SYS_EVENT_MSG);
    }

    // Handle system reset (long press on side key)
    if ( events & ST_SYS_RESET_EVT ) {
        if (sysResetRequest) {
            HAL_SYSTEM_RESET();
        }
        return ( events ^ ST_SYS_RESET_EVT );
    }

    if ( events & ST_START_DEVICE_EVT ) {
        // Start the Device
        VOID GAPRole_StartDevice( &sensorTag_PeripheralCBs );

        // Start Bond Manager
        VOID GAPBondMgr_Register( &sensorTag_BondMgrCBs );

        return ( events ^ ST_START_DEVICE_EVT );
    }

    //////////////////////////
    //    Accelerometer     //
    //////////////////////////
    if ( events & ST_ACCELEROMETER_SENSOR_EVT ) {
        if(accConfig != ST_CFG_SENSOR_DISABLE) {
            readAccData();
            osal_start_timerEx( pine_TaskID, ST_ACCELEROMETER_SENSOR_EVT, sensorAccPeriod );
        } else {
            VOID resetCharacteristicValue( ACCELEROMETER_SERV_UUID, SENSOR_DATA, 0, ACCELEROMETER_DATA_LEN );
            VOID resetCharacteristicValue( ACCELEROMETER_SERV_UUID, SENSOR_CONF, ST_CFG_SENSOR_DISABLE, sizeof ( uint8 ));
        }

        return (events ^ ST_ACCELEROMETER_SENSOR_EVT);
    }
  
#if defined ( PLUS_BROADCASTER )
    if ( events & ST_ADV_IN_CONNECTION_EVT ) {
        uint8 turnOnAdv = TRUE;
        // Turn on advertising while in a connection
        GAPRole_SetParameter( GAPROLE_ADVERT_ENABLED, sizeof( uint8 ), &turnOnAdv );

        return (events ^ ST_ADV_IN_CONNECTION_EVT);
    }
#endif // PLUS_BROADCASTER

    // Discard unknown events
    return 0;
}


/*********************************************************************
* Private functions
*/


/*********************************************************************
 * @fn      sensorTag_ProcessOSALMsg
 *
 * @brief   Process an incoming task message.
 *
 * @param   pMsg - message to process
 *
 * @return  none
 */
static void sensorTag_ProcessOSALMsg( osal_event_hdr_t *pMsg )
{
    switch ( pMsg->event ) {
        case KEY_CHANGE:
            sensorTag_HandleKeys( ((keyChange_t *)pMsg)->state, ((keyChange_t *)pMsg)->keys );
            break;
        ///TODO: click change can be added here to process for the click operation
        ///TODO: or make the click as sw_key process
        default:
            // do nothing
            break;
    }
}

/*********************************************************************
 * @fn      sensorTag_HandleKeys
 *
 * @brief   Handles all key events for this device.
 *
 * @param   shift - true if in shift/alt.
 * @param   keys - bit field for key events. Valid entries:
 *                 HAL_KEY_SW_2
 *                 HAL_KEY_SW_1
 *
 * @return  none
 */
static void sensorTag_HandleKeys( uint8 shift, uint8 keys )
{
    uint8 SK_Keys = 0;
    VOID shift;  // Intentionally unreferenced parameter

    if (keys & HAL_KEY_SW_1) {
        // Reset the system if side key is pressed for more than 3 seconds
        sysResetRequest = TRUE;
        osal_start_timerEx( pine_TaskID, ST_SYS_RESET_EVT, ST_SYS_RESET_DELAY );

        if (!testMode ) { // Side key
            // If device is not in a connection, pressing the side key should toggle
            //  advertising on and off
            if ( gapProfileState != GAPROLE_CONNECTED ) {
                uint8 current_adv_enabled_status;
                uint8 new_adv_enabled_status;

                // Find the current GAP advertising status
                GAPRole_GetParameter( GAPROLE_ADVERT_ENABLED, &current_adv_enabled_status );

                if( current_adv_enabled_status == FALSE ) {
                    new_adv_enabled_status = TRUE;
                } else {
                    new_adv_enabled_status = FALSE;
                }

                // Change the GAP advertisement status to opposite of current status
                GAPRole_SetParameter( GAPROLE_ADVERT_ENABLED, sizeof( uint8 ), &new_adv_enabled_status );
            }

            if ( gapProfileState == GAPROLE_CONNECTED ) {
                uint8 adv_enabled = TRUE;

                // Disconnect
                GAPRole_TerminateConnection();
                // Start advertising
                GAPRole_SetParameter( GAPROLE_ADVERT_ENABLED, sizeof( uint8 ), &adv_enabled );
            }
        } else {
            // Test mode
            if ( keys & HAL_KEY_SW_1 ) { // Side key
                SK_Keys |= SK_KEY_SIDE;
            }
        }
    }

    if ( keys & HAL_KEY_SW_2 ) { // Carbon S2
        SK_Keys |= SK_KEY_LEFT;
    }

    if ( keys & HAL_KEY_SW_3 ) { // Carbon S3
        SK_Keys |= SK_KEY_RIGHT;
    }

    if (!(keys & HAL_KEY_SW_1)) {
        // Cancel system reset request
        sysResetRequest = FALSE;
    }

    // Set the value of the keys state to the Simple Keys Profile;
    // This will send out a notification of the keys state if enabled
    SK_SetParameter( SK_KEY_ATTR, sizeof ( uint8 ), &SK_Keys );
}


/*********************************************************************
 * @fn      resetSensorSetup
 *
 * @brief   Turn off all sensors that are on
 *
 * @param   none
 *
 * @return  none
 */
static void resetSensorSetup (void)
{
    if (accConfig != ST_CFG_SENSOR_DISABLE) {
        accConfig = ST_CFG_SENSOR_DISABLE;
    }

    testMode = FALSE;

    // Reset all characteristics values
    resetCharacteristicValues();
}


/*********************************************************************
 * @fn      peripheralStateNotificationCB
 *
 * @brief   Notification from the profile of a state change.
 *
 * @param   newState - new state
 *
 * @return  none
 */
static void peripheralStateNotificationCB( gaprole_States_t newState )
{
    switch ( newState ) {
        case GAPROLE_STARTED: {
            uint8 ownAddress[B_ADDR_LEN];
            uint8 systemId[DEVINFO_SYSTEM_ID_LEN];

            GAPRole_GetParameter(GAPROLE_BD_ADDR, ownAddress);

            // use 6 bytes of device address for 8 bytes of system ID value
            systemId[0] = ownAddress[0];
            systemId[1] = ownAddress[1];
            systemId[2] = ownAddress[2];

            // set middle bytes to zero
            systemId[4] = 0x00;
            systemId[3] = 0x00;

            // shift three bytes up
            systemId[7] = ownAddress[5];
            systemId[6] = ownAddress[4];
            systemId[5] = ownAddress[3];

            DevInfo_SetParameter(DEVINFO_SYSTEM_ID, DEVINFO_SYSTEM_ID_LEN, systemId);
        }
        break;
        
        case GAPROLE_ADVERTISING:
            HalLedSet(HAL_LED_1, HAL_LED_MODE_ON );
            break;

        case GAPROLE_CONNECTED:
            HalLedSet(HAL_LED_1, HAL_LED_MODE_OFF );
            ccUpdate();
            break;

        case GAPROLE_WAITING:
            // Link terminated intentionally: reset all sensors
            resetSensorSetup();
            break;

        default:
            break;
    }

    gapProfileState = newState;
}

/*********************************************************************
 * @fn      readAccData
 *
 * @brief   Read accelerometer data
 *
 * @param   none
 *
 * @return  none
 */
static void readAccData(void)
{
    uint8 aData[ACCELEROMETER_DATA_LEN];

    if (hal_acc_read(aData)) {
        Accel_SetParameter( SENSOR_DATA, ACCELEROMETER_DATA_LEN, aData);
    }
}


/*********************************************************************
 * @fn      accelChangeCB
 *
 * @brief   Callback from Accelerometer Service indicating a value change
 *
 * @param   paramID - parameter ID of the value that was changed.
 *
 * @return  none
 */
static void accelChangeCB( uint8 paramID )
{
    uint8 newValue;

    switch (paramID) {
        case SENSOR_CONF:
            Accel_GetParameter( SENSOR_CONF, &newValue );
            if ( newValue == ST_CFG_SENSOR_DISABLE) {
                // Put sensor to sleep
                if (accConfig != ST_CFG_SENSOR_DISABLE) {
                    accConfig = ST_CFG_SENSOR_DISABLE;
                    osal_set_event( pine_TaskID, ST_ACCELEROMETER_SENSOR_EVT);
                }
            } else {
                if (accConfig == ST_CFG_SENSOR_DISABLE) {
                    // Start scheduling only on change disabled -> enabled
                    osal_set_event( pine_TaskID, ST_ACCELEROMETER_SENSOR_EVT);
                }
                // Scheduled already, so just change range
                accConfig = newValue;
                hal_acc_set_range(accConfig);
            }
            break;

        case SENSOR_PERI:
            Accel_GetParameter( SENSOR_PERI, &newValue );
            sensorAccPeriod = newValue*SENSOR_PERIOD_RESOLUTION;
            break;

        default:
            // Should not get here
            break;
    }
}


#if defined FEATURE_TEST
/*********************************************************************
 * @fn      testChangeCB
 *
 * @brief   Callback from Test indicating a value change
 *
 * @param   paramID - parameter ID of the value that was changed.
 *
 * @return  none
 */
static void testChangeCB( uint8 paramID )
{
    if( paramID == TEST_CONF_ATTR ) {
        uint8 newValue;

        Test_GetParameter( TEST_CONF_ATTR, &newValue );

        if (newValue & TEST_MODE_ENABLE) {
            testMode = TRUE;
        } else {
            testMode = FALSE;
        }

        if (testMode) {
            // Test mode: possible to operate LEDs. Key hits will cause notifications,
            // side key does not influence connection state
            if (newValue & 0x01) {
                HalLedSet(HAL_LED_1,HAL_LED_MODE_ON);
            } else {
                HalLedSet(HAL_LED_1,HAL_LED_MODE_OFF);
            }

            if (newValue & 0x02) {
                HalLedSet(HAL_LED_2,HAL_LED_MODE_ON);
            } else {
                HalLedSet(HAL_LED_2,HAL_LED_MODE_OFF);
            }
        } else {
            // Normal mode; make sure LEDs are reset and attribute cleared
            HalLedSet(HAL_LED_1,HAL_LED_MODE_OFF);
            HalLedSet(HAL_LED_2,HAL_LED_MODE_OFF);
            newValue = 0x00;
            Test_SetParameter( TEST_CONF_ATTR, 1, &newValue );
        }
    }
}
#endif

/**********************************************************************
 * @fn      ccUpdate
 *
 * @brief   Update the Connection Control service with the current connection
 *          control settings
 *
 */
static void ccUpdate( void )
{
    uint8 buf[CCSERVICE_CHAR1_LEN];
    uint16 connInterval;
    uint16 connSlaveLatency;
    uint16 connTimeout;

    // Get the connection control data
    GAPRole_GetParameter(GAPROLE_CONN_INTERVAL, &connInterval);
    GAPRole_GetParameter(GAPROLE_SLAVE_LATENCY, &connSlaveLatency);
    GAPRole_GetParameter(GAPROLE_CONN_TIMEOUT, &connTimeout);

    buf[0] = LO_UINT16(connInterval);
    buf[1] = HI_UINT16(connInterval);
    buf[2] = LO_UINT16(connSlaveLatency);
    buf[3] = HI_UINT16(connSlaveLatency);
    buf[4] = LO_UINT16(connTimeout);
    buf[5] = HI_UINT16(connTimeout);

    CcService_SetParameter(CCSERVICE_CHAR1,sizeof(buf),buf);
}


/*********************************************************************
 * @fn      ccChangeCB
 *
 * @brief   Callback from Connection Control indicating a value change
 *
 * @param   paramID - parameter ID of the value that was changed.
 *
 * @return  none
 */
static void ccChangeCB( uint8 paramID )
{
    // CCSERVICE_CHAR1: read & notify only

    // CCSERVICE_CHAR: requested connection parameters
    if( paramID == CCSERVICE_CHAR2 ) {
        uint8 buf[CCSERVICE_CHAR2_LEN];
        uint16 minConnInterval;
        uint16 maxConnInterval;
        uint16 slaveLatency;
        uint16 timeoutMultiplier;

        CcService_GetParameter( CCSERVICE_CHAR2, buf );

        minConnInterval = BUILD_UINT16(buf[0],buf[1]);
        maxConnInterval = BUILD_UINT16(buf[2],buf[3]);
        slaveLatency = BUILD_UINT16(buf[4],buf[5]);
        timeoutMultiplier = BUILD_UINT16(buf[6],buf[7]);

        // Update connection parameters
        GAPRole_SendUpdateParam( minConnInterval, maxConnInterval, slaveLatency,
                                 timeoutMultiplier, GAPROLE_NO_ACTION);
    }

    // CCSERVICE_CHAR3: Disconnect request
    if( paramID == CCSERVICE_CHAR3 ) {
        // Any change in the value will terminate the connection
        GAPRole_TerminateConnection();
    }
}


/*********************************************************************
 * @fn      gapRolesParamUpdateCB
 *
 * @brief   Called when connection parameters are updates
 *
 * @param   connInterval - new connection interval
 *
 * @param   connSlaveLatency - new slave latency
 *
 * @param   connTimeout - new connection timeout
 *
 * @return  none
*/
static void gapRolesParamUpdateCB( uint16 connInterval, uint16 connSlaveLatency,
                                   uint16 connTimeout )
{
    uint8 buf[CCSERVICE_CHAR1_LEN];

    buf[0] = LO_UINT16(connInterval);
    buf[1] = HI_UINT16(connInterval);
    buf[2] = LO_UINT16(connSlaveLatency);
    buf[3] = HI_UINT16(connSlaveLatency);
    buf[4] = LO_UINT16(connTimeout);
    buf[5] = HI_UINT16(connTimeout);
    CcService_SetParameter(CCSERVICE_CHAR1,sizeof(buf),buf);
}


/*********************************************************************
 * @fn      resetCharacteristicValue
 *
 * @brief   Initialize a characteristic value to zero
 *
 * @param   servID - service ID (UUID)
 *
 * @param   paramID - parameter ID of the value is to be cleared
 *
 * @param   value - value to initialize with
 *
 * @param   paramLen - length of the parameter
 *
 * @return  none
 */
static void resetCharacteristicValue(uint16 servUuid, uint8 paramID,
                                     uint8 value, uint8 paramLen)
{
    uint8* pData = osal_mem_alloc(paramLen);

    if (pData == NULL) {
        return;
    }

    osal_memset(pData,value,paramLen);

    switch(servUuid) {
        case ACCELEROMETER_SERV_UUID:
            Accel_SetParameter( paramID, paramLen, pData);
            break;

        default:
            // Should not get here
            break;
    }

    osal_mem_free(pData);
}

/*********************************************************************
 * @fn      resetCharacteristicValues
 *
 * @brief   Initialize all the characteristic values
 *
 * @return  none
 */
static void resetCharacteristicValues( void )
{
    resetCharacteristicValue( ACCELEROMETER_SERV_UUID, SENSOR_DATA, 0, ACCELEROMETER_DATA_LEN );
    resetCharacteristicValue( ACCELEROMETER_SERV_UUID, SENSOR_CONF, ST_CFG_SENSOR_DISABLE, sizeof ( uint8 ));
    resetCharacteristicValue( ACCELEROMETER_SERV_UUID, SENSOR_PERI, ACC_DEFAULT_PERIOD / SENSOR_PERIOD_RESOLUTION, sizeof ( uint8 ));
}


/*********************************************************************
*********************************************************************/

