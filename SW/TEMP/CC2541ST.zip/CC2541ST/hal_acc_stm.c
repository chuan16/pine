/* ------------------------------------------------------------------------------------------------
*                                          Includes
* ------------------------------------------------------------------------------------------------
*/

#include "hal_acc_stm.h"
#include "hal_sensor.h"
#include "hal_i2c.h"
#include "hal_board_cfg.h"

/* ------------------------------------------------------------------------------------------------
*                                           Constants
* ------------------------------------------------------------------------------------------------
*/
// Sensor I2C address [I2C will have a R/W as bit0]
#define HAL_LIS3DH_I2C_ADDRESS          0x18



/* ------------------------------------------------------------------------------------------------
*                                           Typedefs
* ------------------------------------------------------------------------------------------------
*/

/* ------------------------------------------------------------------------------------------------
*                                           Macros
* ------------------------------------------------------------------------------------------------
*/

/* ------------------------------------------------------------------------------------------------
*                                           Local Functions
* ------------------------------------------------------------------------------------------------
*/


/*******************************************************************************
* Function Name     : hal_acc_read_reg
* Description       : Generic Reading function. It must be fullfilled with either
*           : I2C or SPI reading functions
* Input         : Register Address
* Output        : Data REad
* Return        : None
*******************************************************************************/
uint8 hal_acc_read_reg(uint8 reg, uint8* data)
{

    //To be completed with either I2c or SPI reading function
    //i.e. *Data = SPI_Mems_Read_Reg( Reg );
    return 1;
}


/*******************************************************************************
* Function Name     : hal_acc_write_reg
* Description       : Generic Writing function. It must be fullfilled with either
*                   : I2C or SPI writing function
* Input             : Register Address, Data to be written
* Output            : None
* Return            : None
*******************************************************************************/
uint8 hal_acc_write_reg(uint8 write_addr, uint8 data)
{

    //To be completed with either I2c or SPI writing function
    //i.e. SPI_Mems_Write_Reg(WriteAddr, Data);
    return 1;
}


/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : hal_acc_get_who_am_i
* Description    : Read identification code by WHO_AM_I register
* Input          : Char to empty by Device identification Value
* Output         : None
* Return         : Status [value of FSS]
*******************************************************************************/
status_t hal_acc_get_who_am_i(uint8* val)
{

    if( !hal_acc_read_reg(ACC_WHO_AM_I, val) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_status_aux
* Description    : Read the AUX status register
* Input          : Char to empty by status register buffer
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_status_aux(uint8* val)
{

    if( !hal_acc_read_reg(ACC_STATUS_AUX, val) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}



/*******************************************************************************
* Function Name  : hal_acc_get_status_aux_bit
* Description    : Read the AUX status register BIT
* Input          : ACC_STATUS_AUX_321OR, ACC_STATUS_AUX_3OR, ACC_STATUS_AUX_2OR, ACC_STATUS_AUX_1OR,
                   ACC_STATUS_AUX_321DA, ACC_STATUS_AUX_3DA, ACC_STATUS_AUX_2DA, ACC_STATUS_AUX_1DA
* Output         : BIT status [MEMS_SET, MEMS_RESET]
* Return         : Status of operation [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_status_aux_bit(uint8 status_bit, uint8* val)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_STATUS_AUX, &value) )
        return MEMS_ERROR;

    if(value &= status_bit) {
        *val = MEMS_SET;
    } else {
        *val = MEMS_RESET;
    }
    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_odr
* Description    : Sets LIS3DH Output Data Rate
* Input          : Output Data Rate
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_odr(acc_odr_t ov)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG1, &value) )
        return MEMS_ERROR;

    value &= 0x0f;
    value |= ov<<ACC_ODR_BIT;

    if( !hal_acc_write_reg(ACC_CTRL_REG1, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}

#if 0
/*******************************************************************************
* Function Name  : hal_acc_set_temperature
* Description    : Sets LIS3DH Output Temperature
* Input          : MEMS_ENABLE, MEMS_DISABLE
* Output         : None
* Note           : For Read Temperature by ACC_OUT_AUX_3, hal_acc_set_adcaux and hal_acc_set_bdu
                   functions must be ENABLE
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_temperature(state_t state)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_TEMP_CFG_REG, &value) )
        return MEMS_ERROR;

    value &= 0xBF;
    value |= state<<ACC_TEMP_EN;

    if( !hal_acc_write_reg(ACC_TEMP_CFG_REG, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}
#endif

/*******************************************************************************
* Function Name  : hal_acc_set_adcaux
* Description    : Sets LIS3DH Output ADC
* Input          : MEMS_ENABLE, MEMS_DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_adcaux(state_t state)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_TEMP_CFG_REG, &value) )
        return MEMS_ERROR;

    value &= 0x7F;
    value |= state<<ACC_ADC_PD;

    if( !hal_acc_write_reg(ACC_TEMP_CFG_REG, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_aux_raw
* Description    : Read the Aux Values Output Registers
* Input          : Buffer to empty
* Output         : Aux Values Registers buffer
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_aux_raw(acc_aux_123_raw_t* buff)
{
    uint8 valueL;
    uint8 valueH;

    if( !hal_acc_read_reg(ACC_OUT_1_L, &valueL) )
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_OUT_1_H, &valueH) )
        return MEMS_ERROR;

    buff->AUX_1 = (uint16)( (valueH << 8) | valueL )/16;  ///TODO: check why 16 is divided

    if( !hal_acc_read_reg(ACC_OUT_2_L, &valueL) )
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_OUT_2_H, &valueH) )
        return MEMS_ERROR;

    buff->AUX_2 = (uint16)( (valueH << 8) | valueL )/16;

    if( !hal_acc_read_reg(ACC_OUT_3_L, &valueL) )
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_OUT_3_H, &valueH) )
        return MEMS_ERROR;

    buff->AUX_3 = (uint16)( (valueH << 8) | valueL )/16;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_mode
* Description    : Sets LIS3DH Operating Mode
* Input          : Modality (ACC_NORMAL, ACC_LOW_POWER, ACC_POWER_DOWN)
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_mode(acc_mode_t md)
{
    uint8 value;
    uint8 value2;
    static uint8 odr_old_value;

    if( !hal_acc_read_reg(ACC_CTRL_REG1, &value) )
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_CTRL_REG4, &value2) )
        return MEMS_ERROR;

    if((value & 0xF0)==0)
        value |= (odr_old_value & 0xF0); //if it comes from POWERDOWN

    switch(md) {

        case ACC_POWER_DOWN:
            odr_old_value = value;
            value &= 0x0F;
            break;

        case ACC_NORMAL:
            value &= 0xF7;
            value2 |= (MEMS_SET << ACC_HR);   //set HighResolution_BIT
            break;

        case ACC_LOW_POWER:
            value |=  (MEMS_SET << ACC_LPEN);
            value2 &= 0xF7;                   //reset HighResolution_BIT
            break;

        default:
            return MEMS_ERROR;
    }

    if( !hal_acc_write_reg(ACC_CTRL_REG1, value) )
        return MEMS_ERROR;

    if( !hal_acc_write_reg(ACC_CTRL_REG4, value2) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_axis
* Description    : Enable/Disable LIS3DH Axis
* Input          : ACC_X_ENABLE/DISABLE | ACC_Y_ENABLE/DISABLE | ACC_Z_ENABLE/DISABLE
* Output         : None
* Note           : You MUST use all input variable in the argument, as example
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_axis(acc_axis_t axis)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG1, &value) )
        return MEMS_ERROR;
    value &= 0xF8;
    value |= (0x07 & axis);

    if( !hal_acc_write_reg(ACC_CTRL_REG1, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_full_scale
* Description    : Sets the LIS3DH FullScale
* Input          : ACC_FULLSCALE_2/ACC_FULLSCALE_4/ACC_FULLSCALE_8/ACC_FULLSCALE_16
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_full_scale(acc_full_scale_t fs)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG4, &value) )
        return MEMS_ERROR;

    value &= 0xCF;
    value |= (fs << ACC_FS);

    if( !hal_acc_write_reg(ACC_CTRL_REG4, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_bdu
* Description    : Enable/Disable Block Data Update Functionality
* Input          : ENABLE/DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_bdu(state_t bdu)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG4, &value) )
        return MEMS_ERROR;

    value &= 0x7F;
    value |= (bdu << ACC_BDU);

    if( !hal_acc_write_reg(ACC_CTRL_REG4, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_ble
* Description    : Set Endianess (MSB/LSB)
* Input          : BLE_LSB / BLE_MSB
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_ble(acc_endianess_t ble)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG4, &value) )
        return MEMS_ERROR;

    value &= 0xBF;
    value |= (ble << ACC_BLE);

    if( !hal_acc_write_reg(ACC_CTRL_REG4, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_self_test
* Description    : Set Self Test Modality
* Input          : ACC_SELF_TEST_DISABLE/ST_0/ST_1
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_self_test(acc_self_test_t st)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG4, &value) )
        return MEMS_ERROR;

    value &= 0xF9;
    value |= (st << ACC_ST);

    if( !hal_acc_write_reg(ACC_CTRL_REG4, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_hpf_click
* Description    : Enable/Disable High Pass Filter for click
* Input          : MEMS_ENABLE/MEMS_DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_hpf_click(state_t hpfe)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value) )
        return MEMS_ERROR;

    value &= 0xFB;
    value |= (hpfe << ACC_HPCLICK);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_hpf_aoi1
* Description    : Enable/Disable High Pass Filter for AOI on INT_1
* Input          : MEMS_ENABLE/MEMS_DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_hpf_aoi1(state_t hpfe)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value) )
        return MEMS_ERROR;

    value &= 0xFE;
    value |= (hpfe<<ACC_HPIS1);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_hpf_aoi2
* Description    : Enable/Disable High Pass Filter for AOI on INT_2
* Input          : MEMS_ENABLE/MEMS_DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_hpf_aoi2(state_t hpfe)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value) )
        return MEMS_ERROR;

    value &= 0xFD;
    value |= (hpfe<<ACC_HPIS2);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_hpf_mode
* Description    : Set High Pass Filter Modality
* Input          : ACC_HPM_NORMAL_MODE_RES/ACC_HPM_REF_SIGNAL/
                   ACC_HPM_NORMAL_MODE/ACC_HPM_AUTORESET_INT
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_hpf_mode(acc_hpf_mode_t hpm)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value) )
        return MEMS_ERROR;

    value &= 0x3F;
    value |= (hpm<<ACC_HPM);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_hpf_cut_off
* Description    : Set High Pass CUT OFF Freq
* Input          : HPFCF [0,3]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_hpf_cut_off(acc_hpf_cut_off_freq_t hpf)
{
    uint8 value;

    if (hpf > 3)
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value) )
        return MEMS_ERROR;

    value &= 0xCF;
    value |= (hpf<<ACC_HPCF);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;

}


/*******************************************************************************
* Function Name  : hal_acc_set_filter_data_sel
* Description    : Set Filter Data Selection bypassed or sent to FIFO OUT register
* Input          : MEMS_SET, MEMS_RESET
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_filter_data_sel(state_t state)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value) )
        return MEMS_ERROR;

    value &= 0xF7;
    value |= (state<<ACC_FDS);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;

}


/*******************************************************************************
* Function Name  : hal_acc_set_int1_pin
* Description    : Set Interrupt1 pin Function
* Input          :  ACC_CLICK_ON_PIN_INT1_ENABLE/DISABLE    | ACC_I1_INT1_ON_PIN_INT1_ENABLE/DISABLE |
                    ACC_I1_INT2_ON_PIN_INT1_ENABLE/DISABLE  | ACC_I1_DRDY1_ON_INT1_ENABLE/DISABLE    |
                    ACC_I1_DRDY2_ON_INT1_ENABLE/DISABLE     | ACC_WTM_ON_INT1_ENABLE/DISABLE         |
                    ACC_INT1_OVERRUN_ENABLE/DISABLE
* example        : SetInt1Pin(ACC_CLICK_ON_PIN_INT1_ENABLE | ACC_I1_INT1_ON_PIN_INT1_ENABLE |
                    ACC_I1_INT2_ON_PIN_INT1_DISABLE | ACC_I1_DRDY1_ON_INT1_ENABLE | ACC_I1_DRDY2_ON_INT1_ENABLE |
                    ACC_WTM_ON_INT1_DISABLE | ACC_INT1_OVERRUN_DISABLE   )
* Note           : To enable Interrupt signals on INT1 Pad (You MUST use all input variable in the argument, as example)
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int1_pin(acc_int_pin_config_t pinConf)
{
    if( !hal_acc_write_reg(ACC_CTRL_REG3, pinConf) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int2_pin
* Description    : Set Interrupt2 pin Function
* Input          : ACC_CLICK_ON_PIN_INT2_ENABLE/DISABLE   | ACC_I2_INT1_ON_PIN_INT2_ENABLE/DISABLE |
                   ACC_I2_INT2_ON_PIN_INT2_ENABLE/DISABLE | ACC_I2_BOOT_ON_INT2_ENABLE/DISABLE |
                   ACC_INT_ACTIVE_HIGH/LOW
* example        : hal_acc_set_int2_pin(ACC_CLICK_ON_PIN_INT2_ENABLE/DISABLE | ACC_I2_INT1_ON_PIN_INT2_ENABLE/DISABLE |
                   ACC_I2_INT2_ON_PIN_INT2_ENABLE/DISABLE | ACC_I2_BOOT_ON_INT2_ENABLE/DISABLE |
                   ACC_INT_ACTIVE_HIGH/LOW)
* Note           : To enable Interrupt signals on INT2 Pad (You MUST use all input variable in the argument, as example)
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int2_pin(acc_int_pin_config_t pinConf)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG6, &value) )
        return MEMS_ERROR;

    value &= 0x2D;
    value |= pinConf;

    if( !hal_acc_write_reg(ACC_CTRL_REG6, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_click_config
* Description    : Set Click Interrupt config Function
* Input          : ACC_ZD_ENABLE/DISABLE | ACC_ZS_ENABLE/DISABLE  | ACC_YD_ENABLE/DISABLE  |
                   ACC_YS_ENABLE/DISABLE | ACC_XD_ENABLE/DISABLE  | ACC_XS_ENABLE/DISABLE
* example        : hal_acc_set_click_config( ACC_ZD_ENABLE | ACC_ZS_DISABLE | ACC_YD_ENABLE |
                               ACC_YS_DISABLE | ACC_XD_ENABLE | ACC_XS_ENABLE)
* Note           : You MUST use all input variable in the argument, as example
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_click_config(uint8 status)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CLICK_CFG, &value) )
        return MEMS_ERROR;

    value &= 0xC0;
    value |= status;

    if( !hal_acc_write_reg(ACC_CLICK_CFG, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_click_threshold
* Description    : Set Click Interrupt threshold
* Input          : Click-click Threshold value [0-127]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_click_threshold(uint8 ths)
{

    if(ths>127)
        return MEMS_ERROR;

    if( !hal_acc_write_reg(ACC_CLICK_THS, ths) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_click_limit
* Description    : Set Click Interrupt Time Limit
* Input          : Click-click Time Limit value [0-127]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_click_limit(uint8 t_limit)
{

    if(t_limit>127)
        return MEMS_ERROR;

    if( !hal_acc_write_reg(ACC_TIME_LIMIT, t_limit) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_click_latency
* Description    : Set Click Interrupt Time Latency
* Input          : Click-click Time Latency value [0-255]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_click_latency(uint8 t_latency)
{

    if( !hal_acc_write_reg(ACC_TIME_LATENCY, t_latency) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_click_window
* Description    : Set Click Interrupt Time Window
* Input          : Click-click Time Window value [0-255]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_click_window(uint8 t_window)
{

    if( !hal_acc_write_reg(ACC_TIME_WINDOW, t_window) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_click_response
* Description    : Get Click Interrupt Response by CLICK_SRC REGISTER
* Input          : char to empty by Click Response Typedef
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_click_response(uint8* res)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CLICK_SRC, &value) )
        return MEMS_ERROR;

    value &= 0x7F;

    if((value & ACC_IA)==0) {
        *res = ACC_NO_CLICK;
        return MEMS_SUCCESS;
    } else {
        ///TODO: here may need to change with debug result, this is a sequencial check
        if (value & ACC_DCLICK) {
            if (value & ACC_CLICK_SIGN) {
                if (value & ACC_CLICK_Z) {
                    *res = ACC_DCLICK_Z_N;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_Y) {
                    *res = ACC_DCLICK_Y_N;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_X) {
                    *res = ACC_DCLICK_X_N;
                    return MEMS_SUCCESS;
                }
            } else {
                if (value & ACC_CLICK_Z) {
                    *res = ACC_DCLICK_Z_P;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_Y) {
                    *res = ACC_DCLICK_Y_P;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_X) {
                    *res = ACC_DCLICK_X_P;
                    return MEMS_SUCCESS;
                }
            }
        } else {
            if (value & ACC_CLICK_SIGN) {
                if (value & ACC_CLICK_Z) {
                    *res = ACC_SCLICK_Z_N;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_Y) {
                    *res = ACC_SCLICK_Y_N;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_X) {
                    *res = ACC_SCLICK_X_N;
                    return MEMS_SUCCESS;
                }
            } else {
                if (value & ACC_CLICK_Z) {
                    *res = ACC_SCLICK_Z_P;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_Y) {
                    *res = ACC_SCLICK_Y_P;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_X) {
                    *res = ACC_SCLICK_X_P;
                    return MEMS_SUCCESS;
                }
            }
        }
    }
    return MEMS_ERROR;
}


/*******************************************************************************
* Function Name  : hal_acc_int1_latch_enable
* Description    : Enable Interrupt 1 Latching function
* Input          : ENABLE/DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int1_latch(state_t latch)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG5, &value) )
        return MEMS_ERROR;

    value &= 0xF7;
    value |= latch<<ACC_LIR_INT1;

    if( !hal_acc_write_reg(ACC_CTRL_REG5, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_clear_int1_src
* Description    : Read clear INT1 src
* Input          : None
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_clear_int1_src(void)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_INT1_SRC, &value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int_config
* Description    : Interrupt 1 Configuration (without ACC_6D_INT)
* Input          : ACC_INT1_AND/OR | ACC_INT1_ZHIE_ENABLE/DISABLE | ACC_INT1_ZLIE_ENABLE/DISABLE...
* Output         : None
* Note           : You MUST use all input variable in the argument, as example
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int_config(acc_int1_config_t ic)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_INT1_CFG, &value) )
        return MEMS_ERROR;

    value &= 0x40;
    value |= ic;

    if( !hal_acc_write_reg(ACC_INT1_CFG, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int_mode
* Description    : Interrupt 1 Configuration mode (OR, 6D Movement, AND, 6D Position)
* Input          : ACC_INT_MODE_OR, ACC_INT_MODE_6D_MOVEMENT, ACC_INT_MODE_AND,
                   ACC_INT_MODE_6D_POSITION
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int_mode(acc_int1_mode_t int_mode)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_INT1_CFG, &value) )
        return MEMS_ERROR;

    value &= 0x3F;
    value |= (int_mode<<ACC_INT_6D);

    if( !hal_acc_write_reg(ACC_INT1_CFG, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int_6d_4d_config
* Description    : 6D, 4D Interrupt Configuration
* Input          : ACC_INT1_6D_ENABLE, ACC_INT1_4D_ENABLE, ACC_INT1_6D_4D_DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int_6d_4d_config(acc_int_6d_4d_t ic)
{
    uint8 value;
    uint8 value2;

    if( !hal_acc_read_reg(ACC_INT1_CFG, &value) )
        return MEMS_ERROR;
    if( !hal_acc_read_reg(ACC_CTRL_REG5, &value2) )
        return MEMS_ERROR;

    if(ic == ACC_INT1_6D_ENABLE) {
        value |= (MEMS_ENABLE<<ACC_INT_6D);
        value2 &= 0xFB;
    }

    if(ic == ACC_INT1_4D_ENABLE) {
        value |= (MEMS_ENABLE<<ACC_INT_6D);
        value2 |= (MEMS_ENABLE<<ACC_D4D_INT1);
    }

    if(ic == ACC_INT1_6D_4D_DISABLE) {
        value &= 0xBF;
        value2 &= 0xFB;
    }

    if( !hal_acc_write_reg(ACC_INT1_CFG, value) )
        return MEMS_ERROR;
    if( !hal_acc_write_reg(ACC_CTRL_REG5, value2) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_6d_position
* Description    : 6D, 4D Interrupt Position Detect
* Input          : Byte to empty by POSITION_6D_t Typedef
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_6d_position(uint8* val)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_INT1_SRC, &value) )
        return MEMS_ERROR;

    value &= 0x7F;

    switch (value) {
        case ACC_UP_SX:
            *val = ACC_UP_SX;
            break;
        case ACC_UP_DX:
            *val = ACC_UP_DX;
            break;
        case ACC_DW_SX:
            *val = ACC_DW_SX;
            break;
        case ACC_DW_DX:
            *val = ACC_DW_DX;
            break;
        case ACC_TOP:
            *val = ACC_TOP;
            break;
        case ACC_BOTTOM:
            *val = ACC_BOTTOM;
            break;
    }

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int1_threshold
* Description    : Sets Interrupt 1 Threshold
* Input          : Threshold = [0,31]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int1_threshold(uint8 ths)
{
    if (ths > 127)
        return MEMS_ERROR;

    if( !hal_acc_write_reg(ACC_INT1_THS, ths) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int1_duration
* Description    : Sets Interrupt 1 Duration
* Input          : Duration value
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int1_duration(acc_int1_config_t id)
{

    if (id > 127)
        return MEMS_ERROR;

    if( !hal_acc_write_reg(ACC_INT1_DURATION, id) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_fifo_mode_enable
* Description    : Sets Fifo Modality
* Input          : ACC_FIFO_DISABLE, ACC_FIFO_BYPASS_MODE, ACC_FIFO_MODE,
                   ACC_FIFO_STREAM_MODE, ACC_FIFO_TRIGGER_MODE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_fifo_mode_enable(acc_fifo_mode_t fm)
{
    uint8 value;

    if(fm == ACC_FIFO_DISABLE) {
        if( !hal_acc_read_reg(ACC_FIFO_CTRL_REG, &value) )
            return MEMS_ERROR;

        value &= 0x1F;
        value |= (ACC_FIFO_BYPASS_MODE<<ACC_FM);

        if( !hal_acc_write_reg(ACC_FIFO_CTRL_REG, value) )           //fifo mode bypass
            return MEMS_ERROR;
        if( !hal_acc_read_reg(ACC_CTRL_REG5, &value) )
            return MEMS_ERROR;

        value &= 0xBF;

        if( !hal_acc_write_reg(ACC_CTRL_REG5, value) )               //fifo disable
            return MEMS_ERROR;
    } else {   //ACC_FIFO_BYPASS_MODE, ACC_FIFO_MODE, ACC_FIFO_STREAM_MODE, ACC_FIFO_TRIGGER_MODE
        if( !hal_acc_read_reg(ACC_CTRL_REG5, &value) )
            return MEMS_ERROR;

        value &= 0xBF;
        value |= MEMS_SET<<ACC_FIFO_EN;

        if( !hal_acc_write_reg(ACC_CTRL_REG5, value) )               //fifo enable
            return MEMS_ERROR;
        if( !hal_acc_read_reg(ACC_FIFO_CTRL_REG, &value) )
            return MEMS_ERROR;

        value &= 0x1f;
        value |= (fm<<ACC_FM);                     //fifo mode configuration

        if( !hal_acc_write_reg(ACC_FIFO_CTRL_REG, value) )
            return MEMS_ERROR;
    }

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_trigger_int
* Description    : Trigger event liked to trigger signal INT1/INT2
* Input          : ACC_TRIG_INT1/ACC_TRIG_INT2
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_trigger_int(acc_trig_int_t tr)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_FIFO_CTRL_REG, &value) )
        return MEMS_ERROR;

    value &= 0xDF;
    value |= (tr<<ACC_TR);

    if( !hal_acc_write_reg(ACC_FIFO_CTRL_REG, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_water_mark
* Description    : Sets Watermark Value
* Input          : Watermark = [0,31]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_water_mark(uint8 wtm)
{
    uint8 value;

    if(wtm > 31)
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_FIFO_CTRL_REG, &value) )
        return MEMS_ERROR;

    value &= 0xE0;
    value |= wtm;

    if( !hal_acc_write_reg(ACC_FIFO_CTRL_REG, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_status_reg
* Description    : Read the status register
* Input          : char to empty by Status Reg Value
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_status_reg(uint8* val)
{
    if( !hal_acc_read_reg(ACC_STATUS_REG, val) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_status_bit
* Description    : Read the status register BIT
* Input          : ACC_STATUS_REG_ZYXOR, ACC_STATUS_REG_ZOR, ACC_STATUS_REG_YOR, ACC_STATUS_REG_XOR,
                   ACC_STATUS_REG_ZYXDA, ACC_STATUS_REG_ZDA, ACC_STATUS_REG_YDA, ACC_STATUS_REG_XDA,
                   ACC_DATAREADY_BIT
                   val: Byte to be filled with the status bit
* Output         : status register BIT
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_status_bit(uint8 status_bit, uint8* val)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_STATUS_REG, &value) )
        return MEMS_ERROR;

    if(value &= status_bit) {
        *val = MEMS_SET;
    } else {
        *val = MEMS_RESET;
    }

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_axes_value
* Description    : Read the Acceleration Values Output Registers
* Input          : buffer to empity by axes_raw_t Typedef
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_axes_value(axes_raw_t* buff)
{
    int16 value;
    uint8 *valueL = (uint8 *)(&value);
    uint8 *valueH = ((uint8 *)(&value)+1);

    if( !hal_acc_read_reg(ACC_OUT_X_L, valueL) )
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_OUT_X_H, valueH) )
        return MEMS_ERROR;

    buff->AXIS_X = value;

    if( !hal_acc_read_reg(ACC_OUT_Y_L, valueL) )
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_OUT_Y_H, valueH) )
        return MEMS_ERROR;

    buff->AXIS_Y = value;

    if( !hal_acc_read_reg(ACC_OUT_Z_L, valueL) )
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_OUT_Z_H, valueH) )
        return MEMS_ERROR;

    buff->AXIS_Z = value;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_int1_src
* Description    : Reset Interrupt 1 Latching function
* Input          : Char to empty by Int1 source value
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_int1_src(uint8* val)
{

    if( !hal_acc_read_reg(ACC_INT1_SRC, val) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_int1_src_bit
* Description    : Reset Interrupt 1 Latching function
* Input          : statusBIT: ACC_INT1_SRC_IA, ACC_INT1_SRC_ZH, ACC_INT1_SRC_ZL.....
*                  val: Byte to be filled with the status bit
* Output         : None
* Return         : Status of BIT [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_int1_src_bit(uint8 status_bit, uint8* val)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_INT1_SRC, &value) )
        return MEMS_ERROR;

    if(value &= status_bit) {
        *val = MEMS_SET;
    } else {
        *val = MEMS_RESET;
    }
    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_fifo_source_reg
* Description    : Read Fifo source Register
* Input          : Byte to empty by FIFO source register value
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_fifo_source_reg(uint8* val)
{

    if( !hal_acc_read_reg(ACC_FIFO_SRC_REG, val) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_fifo_source_bit
* Description    : Read Fifo WaterMark source bit
* Input          : statusBIT: ACC_FIFO_SRC_WTM, ACC_FIFO_SRC_OVRUN, ACC_FIFO_SRC_EMPTY
*                  val: Byte to fill  with the bit value
* Output         : None
* Return         : Status of BIT [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_fifo_source_bit(uint8 status_bit,  uint8* val)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_FIFO_SRC_REG, &value) )
        return MEMS_ERROR;

    if(value &= status_bit) {
        *val = MEMS_SET;
    } else {
        *val = MEMS_RESET;
    }
    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_unread_sample_in_fifo
* Description    : Read current number of unread samples stored in FIFO
* Input          : Byte to empty by FIFO unread sample value
* Output         : None
* Return         : Status [value of FSS]
*******************************************************************************/
status_t hal_acc_get_unread_sample_in_fifo(uint8* val)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_FIFO_SRC_REG, &value) )
        return MEMS_ERROR;

    value &= 0x1F;

    *val = value;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_spi_interface
* Description    : Set SPI mode: 3 Wire Interface OR 4 Wire Interface
* Input          : ACC_SPI_3_WIRE, ACC_SPI_4_WIRE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_spi_interface(acc_spi_mode_t spi)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG4, &value) )
        return MEMS_ERROR;

    value &= 0xFE;
    value |= spi<<ACC_SIM;

    if( !hal_acc_write_reg(ACC_CTRL_REG4, value) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}
