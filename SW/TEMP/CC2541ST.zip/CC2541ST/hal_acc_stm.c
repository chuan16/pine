/* ------------------------------------------------------------------------------------------------
*                                          Includes
* ------------------------------------------------------------------------------------------------
*/

#include "hal_acc_stm.h"
#include "hal_sensor.h"
#include "hal_i2c.h"
#include "hal_board_cfg.h"

/* ------------------------------------------------------------------------------------------------
*                                           Constants
* ------------------------------------------------------------------------------------------------
*/

/* ------------------------------------------------------------------------------------------------
*                                           Typedefs
* ------------------------------------------------------------------------------------------------
*/

/* ------------------------------------------------------------------------------------------------
*                                           Macros
* ------------------------------------------------------------------------------------------------
*/

/* ------------------------------------------------------------------------------------------------
*                                           Local Functions
* ------------------------------------------------------------------------------------------------
*/

static uint8 buffer[24];

/**************************************************************************************************
 * @fn          hal_acc_read_reg
 *
 * @brief       This function implements the I2C protocol to read from a sensor. The sensor must
 *              be selected before this routine is called.
 *
 * @param       addr - which register to read
 * @param       pBuf - pointer to buffer to place data
 * @param       nBytes - numbver of bytes to read
 *
 * @return      TRUE if the required number of bytes are reveived
 **************************************************************************************************/
status_t hal_acc_read_reg(uint8 addr, uint8 *pBuf, uint8 nBytes)
{
    uint8 i = 0;

    /* Send address we're reading from */
    if (HalI2CWrite(1,&addr) == 1) {
        /* Now read data */
        i = HalI2CRead(nBytes,pBuf);
    }

    return (i == nBytes) ? MEMS_SUCCESS : MEMS_ERROR;
}

/**************************************************************************************************
* @fn          hal_acc_write_reg
* @brief       This function implements the I2C protocol to write to a sensor. he sensor must
*              be selected before this routine is called.
*
* @param       addr - which register to write
* @param       pBuf - pointer to buffer containing data to be written
* @param       nBytes - number of bytes to write
*
* @return      TRUE if successful write
*/
status_t hal_acc_write_reg(uint8 addr, uint8 *pBuf, uint8 nBytes)
{
    uint8 i;
    uint8 *p = buffer;

    /* Copy address and data to local buffer for burst write */
    *p++ = addr;
    for (i = 0; i < nBytes; i++) {
        *p++ = *pBuf++;
    }
    nBytes++;

    /* Send address and data */
    i = HalI2CWrite(nBytes, buffer);
    if ( i!= nBytes) {
        //HAL_TOGGLE_LED2();
    }


    return (i == nBytes) ? MEMS_SUCCESS : MEMS_ERROR;
}


/*******************************************************************************
* Function Name  : hal_acc_set_odr
* Description    : Sets LIS3DH Output Data Rate
* Input          : Output Data Rate
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_odr(acc_odr_t ov)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG1, &value, 1) )
        return MEMS_ERROR;

    value &= 0x0f;
    value |= ov<<ACC_ODR_BIT;

    if( !hal_acc_write_reg(ACC_CTRL_REG1, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}

/*******************************************************************************
* Function Name  : hal_acc_set_mode
* Description    : Sets LIS3DH Operating Mode
* Input          : Modality (ACC_NORMAL, ACC_LOW_POWER, ACC_POWER_DOWN)
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_mode(acc_mode_t md)
{
    uint8 value;
    uint8 value2;
    static uint8 odr_old_value;

    if( !hal_acc_read_reg(ACC_CTRL_REG1, &value, 1) )
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_CTRL_REG4, &value2, 1) )
        return MEMS_ERROR;

    if((value & 0xF0)==0)
        value |= (odr_old_value & 0xF0); //if it comes from POWERDOWN

    switch(md) {

        case ACC_POWER_DOWN:
            odr_old_value = value;
            value &= 0x0F;
            break;

        case ACC_NORMAL:
            value &= 0xF7;
            value2 |= (MEMS_SET << ACC_HR);   //set HighResolution_BIT
            break;

        case ACC_LOW_POWER:
            value |=  (MEMS_SET << ACC_LPEN);
            value2 &= 0xF7;                   //reset HighResolution_BIT
            break;

        default:
            return MEMS_ERROR;
    }

    if( !hal_acc_write_reg(ACC_CTRL_REG1, &value, 1) )
        return MEMS_ERROR;

    if( !hal_acc_write_reg(ACC_CTRL_REG4, &value2, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_full_scale
* Description    : Sets the LIS3DH FullScale
* Input          : ACC_FULLSCALE_2/ACC_FULLSCALE_4/ACC_FULLSCALE_8/ACC_FULLSCALE_16
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_full_scale(acc_full_scale_t fs)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG4, &value, 1) )
        return MEMS_ERROR;

    value &= 0xCF;
    value |= (fs << ACC_FS);

    if( !hal_acc_write_reg(ACC_CTRL_REG4, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_hpf_click
* Description    : Enable/Disable High Pass Filter for click
* Input          : MEMS_ENABLE/MEMS_DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_hpf_click(state_t hpfe)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    value &= 0xFB;
    value |= (hpfe << ACC_HPCLICK);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_hpf_aoi1
* Description    : Enable/Disable High Pass Filter for AOI on INT_1
* Input          : MEMS_ENABLE/MEMS_DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_hpf_aoi1(state_t hpfe)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    value &= 0xFE;
    value |= (hpfe<<ACC_HPIS1);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_hpf_aoi2
* Description    : Enable/Disable High Pass Filter for AOI on INT_2
* Input          : MEMS_ENABLE/MEMS_DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_hpf_aoi2(state_t hpfe)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    value &= 0xFD;
    value |= (hpfe<<ACC_HPIS2);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_hpf_mode
* Description    : Set High Pass Filter Modality
* Input          : ACC_HPM_NORMAL_MODE_RES/ACC_HPM_REF_SIGNAL/
                   ACC_HPM_NORMAL_MODE/ACC_HPM_AUTORESET_INT
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_hpf_mode(acc_hpf_mode_t hpm)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    value &= 0x3F;
    value |= (hpm<<ACC_HPM);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_hpf_cut_off
* Description    : Set High Pass CUT OFF Freq
* Input          : HPFCF [0,3]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_hpf_cut_off(acc_hpf_cut_off_freq_t hpf)
{
    uint8 value;

    if (hpf > 3)
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    value &= 0xCF;
    value |= (hpf<<ACC_HPCF);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;

}


/*******************************************************************************
* Function Name  : hal_acc_set_filter_data_sel
* Description    : Set Filter Data Selection bypassed or sent to FIFO OUT register
* Input          : MEMS_SET, MEMS_RESET
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_filter_data_sel(state_t state)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    value &= 0xF7;
    value |= (state<<ACC_FDS);

    if( !hal_acc_write_reg(ACC_CTRL_REG2, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;

}


/*******************************************************************************
* Function Name  : hal_acc_set_int1_pin
* Description    : Set Interrupt1 pin Function
* Input          :  ACC_CLICK_ON_PIN_INT1_ENABLE/DISABLE    | ACC_I1_INT1_ON_PIN_INT1_ENABLE/DISABLE |
                    ACC_I1_INT2_ON_PIN_INT1_ENABLE/DISABLE  | ACC_I1_DRDY1_ON_INT1_ENABLE/DISABLE    |
                    ACC_I1_DRDY2_ON_INT1_ENABLE/DISABLE     | ACC_WTM_ON_INT1_ENABLE/DISABLE         |
                    ACC_INT1_OVERRUN_ENABLE/DISABLE
* example        : SetInt1Pin(ACC_CLICK_ON_PIN_INT1_ENABLE | ACC_I1_INT1_ON_PIN_INT1_ENABLE |
                    ACC_I1_INT2_ON_PIN_INT1_DISABLE | ACC_I1_DRDY1_ON_INT1_ENABLE | ACC_I1_DRDY2_ON_INT1_ENABLE |
                    ACC_WTM_ON_INT1_DISABLE | ACC_INT1_OVERRUN_DISABLE   )
* Note           : To enable Interrupt signals on INT1 Pad (You MUST use all input variable in the argument, as example)
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int1_pin(acc_int_pin_config_t pinConf)
{
    if( !hal_acc_write_reg(ACC_CTRL_REG3, &pinConf, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int2_pin
* Description    : Set Interrupt2 pin Function
* Input          : ACC_CLICK_ON_PIN_INT2_ENABLE/DISABLE   | ACC_I2_INT1_ON_PIN_INT2_ENABLE/DISABLE |
                   ACC_I2_INT2_ON_PIN_INT2_ENABLE/DISABLE | ACC_I2_BOOT_ON_INT2_ENABLE/DISABLE |
                   ACC_INT_ACTIVE_HIGH/LOW
* example        : hal_acc_set_int2_pin(ACC_CLICK_ON_PIN_INT2_ENABLE/DISABLE | ACC_I2_INT1_ON_PIN_INT2_ENABLE/DISABLE |
                   ACC_I2_INT2_ON_PIN_INT2_ENABLE/DISABLE | ACC_I2_BOOT_ON_INT2_ENABLE/DISABLE |
                   ACC_INT_ACTIVE_HIGH/LOW)
* Note           : To enable Interrupt signals on INT2 Pad (You MUST use all input variable in the argument, as example)
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int2_pin(acc_int_pin_config_t pinConf)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG6, &value, 1) )
        return MEMS_ERROR;

    value &= 0x2D;
    value |= pinConf;

    if( !hal_acc_write_reg(ACC_CTRL_REG6, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_click_config
* Description    : Set Click Interrupt config Function
* Input          : ACC_ZD_ENABLE/DISABLE | ACC_ZS_ENABLE/DISABLE  | ACC_YD_ENABLE/DISABLE  |
                   ACC_YS_ENABLE/DISABLE | ACC_XD_ENABLE/DISABLE  | ACC_XS_ENABLE/DISABLE
* example        : hal_acc_set_click_config( ACC_ZD_ENABLE | ACC_ZS_DISABLE | ACC_YD_ENABLE |
                               ACC_YS_DISABLE | ACC_XD_ENABLE | ACC_XS_ENABLE)
* Note           : You MUST use all input variable in the argument, as example
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_click_config(uint8 status)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CLICK_CFG, &value, 1) )
        return MEMS_ERROR;

    value &= 0xC0;
    value |= status;

    if( !hal_acc_write_reg(ACC_CLICK_CFG, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_click_threshold
* Description    : Set Click Interrupt threshold
* Input          : Click-click Threshold value [0-127]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_click_threshold(uint8 ths)
{

    if(ths>127)
        return MEMS_ERROR;

    if( !hal_acc_write_reg(ACC_CLICK_THS, &ths, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_click_limit
* Description    : Set Click Interrupt Time Limit
* Input          : Click-click Time Limit value [0-127]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_click_limit(uint8 t_limit)
{

    if(t_limit>127)
        return MEMS_ERROR;

    if( !hal_acc_write_reg(ACC_TIME_LIMIT, &t_limit, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_click_latency
* Description    : Set Click Interrupt Time Latency
* Input          : Click-click Time Latency value [0-255]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_click_latency(uint8 t_latency)
{

    if( !hal_acc_write_reg(ACC_TIME_LATENCY, &t_latency, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_click_window
* Description    : Set Click Interrupt Time Window
* Input          : Click-click Time Window value [0-255]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_click_window(uint8 t_window)
{

    if( !hal_acc_write_reg(ACC_TIME_WINDOW, &t_window, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_click_response
* Description    : Get Click Interrupt Response by CLICK_SRC REGISTER
* Input          : char to empty by Click Response Typedef
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_click_response(uint8* res)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CLICK_SRC, &value, 1) )
        return MEMS_ERROR;

    value &= 0x7F;

    if((value & ACC_IA)==0) {
        *res = ACC_NO_CLICK;
        return MEMS_SUCCESS;
    } else {
        ///TODO: here may need to change with debug result, this is a sequencial check
        if (value & ACC_DCLICK) {
            if (value & ACC_CLICK_SIGN) {
                if (value & ACC_CLICK_Z) {
                    *res = ACC_DCLICK_Z_N;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_Y) {
                    *res = ACC_DCLICK_Y_N;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_X) {
                    *res = ACC_DCLICK_X_N;
                    return MEMS_SUCCESS;
                }
            } else {
                if (value & ACC_CLICK_Z) {
                    *res = ACC_DCLICK_Z_P;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_Y) {
                    *res = ACC_DCLICK_Y_P;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_X) {
                    *res = ACC_DCLICK_X_P;
                    return MEMS_SUCCESS;
                }
            }
        } else {
            if (value & ACC_CLICK_SIGN) {
                if (value & ACC_CLICK_Z) {
                    *res = ACC_SCLICK_Z_N;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_Y) {
                    *res = ACC_SCLICK_Y_N;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_X) {
                    *res = ACC_SCLICK_X_N;
                    return MEMS_SUCCESS;
                }
            } else {
                if (value & ACC_CLICK_Z) {
                    *res = ACC_SCLICK_Z_P;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_Y) {
                    *res = ACC_SCLICK_Y_P;
                    return MEMS_SUCCESS;
                }
                if (value & ACC_CLICK_X) {
                    *res = ACC_SCLICK_X_P;
                    return MEMS_SUCCESS;
                }
            }
        }
    }
    return MEMS_ERROR;
}


/*******************************************************************************
* Function Name  : hal_acc_int1_latch_enable
* Description    : Enable Interrupt 1 Latching function
* Input          : ENABLE/DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int1_latch(state_t latch)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG5, &value, 1) )
        return MEMS_ERROR;

    value &= 0xF7;
    value |= latch<<ACC_LIR_INT1;

    if( !hal_acc_write_reg(ACC_CTRL_REG5, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_clear_int1_src
* Description    : Read clear INT1 src
* Input          : None
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_clear_int1_src(void)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_INT1_SRC, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int_config
* Description    : Interrupt 1 Configuration (without ACC_6D_INT)
* Input          : ACC_INT1_AND/OR | ACC_INT1_ZHIE_ENABLE/DISABLE | ACC_INT1_ZLIE_ENABLE/DISABLE...
* Output         : None
* Note           : You MUST use all input variable in the argument, as example
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int_config(acc_int1_config_t ic)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_INT1_CFG, &value, 1) )
        return MEMS_ERROR;

    value &= 0x40;
    value |= ic;

    if( !hal_acc_write_reg(ACC_INT1_CFG, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int_mode
* Description    : Interrupt 1 Configuration mode (OR, 6D Movement, AND, 6D Position)
* Input          : ACC_INT_MODE_OR, ACC_INT_MODE_6D_MOVEMENT, ACC_INT_MODE_AND,
                   ACC_INT_MODE_6D_POSITION
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int_mode(acc_int1_mode_t int_mode)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_INT1_CFG, &value, 1) )
        return MEMS_ERROR;

    value &= 0x3F;
    value |= (int_mode<<ACC_INT_6D);

    if( !hal_acc_write_reg(ACC_INT1_CFG, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int_6d_4d_config
* Description    : 6D, 4D Interrupt Configuration
* Input          : ACC_INT1_6D_ENABLE, ACC_INT1_4D_ENABLE, ACC_INT1_6D_4D_DISABLE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int_6d_4d_config(acc_int_6d_4d_t ic)
{
    uint8 value;
    uint8 value2;

    if( !hal_acc_read_reg(ACC_INT1_CFG, &value, 1) )
        return MEMS_ERROR;
    if( !hal_acc_read_reg(ACC_CTRL_REG5, &value2, 1) )
        return MEMS_ERROR;

    if(ic == ACC_INT1_6D_ENABLE) {
        value |= (MEMS_ENABLE<<ACC_INT_6D);
        value2 &= 0xFB;
    }

    if(ic == ACC_INT1_4D_ENABLE) {
        value |= (MEMS_ENABLE<<ACC_INT_6D);
        value2 |= (MEMS_ENABLE<<ACC_D4D_INT1);
    }

    if(ic == ACC_INT1_6D_4D_DISABLE) {
        value &= 0xBF;
        value2 &= 0xFB;
    }

    if( !hal_acc_write_reg(ACC_INT1_CFG, &value, 1) )
        return MEMS_ERROR;
    if( !hal_acc_write_reg(ACC_CTRL_REG5, &value2, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_6d_position
* Description    : 6D, 4D Interrupt Position Detect
* Input          : Byte to empty by POSITION_6D_t Typedef
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_6d_position(uint8* val)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_INT1_SRC, &value, 1) )
        return MEMS_ERROR;

    value &= 0x7F;

    switch (value) {
        case ACC_UP_SX:
            *val = ACC_UP_SX;
            break;
        case ACC_UP_DX:
            *val = ACC_UP_DX;
            break;
        case ACC_DW_SX:
            *val = ACC_DW_SX;
            break;
        case ACC_DW_DX:
            *val = ACC_DW_DX;
            break;
        case ACC_TOP:
            *val = ACC_TOP;
            break;
        case ACC_BOTTOM:
            *val = ACC_BOTTOM;
            break;
    }

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int1_threshold
* Description    : Sets Interrupt 1 Threshold
* Input          : Threshold = [0,31]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int1_threshold(uint8 ths)
{
    if (ths > 127)
        return MEMS_ERROR;

    if( !hal_acc_write_reg(ACC_INT1_THS, &ths, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_int1_duration
* Description    : Sets Interrupt 1 Duration
* Input          : Duration value
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_int1_duration(acc_int1_config_t id)
{

    if (id > 127)
        return MEMS_ERROR;

    if( !hal_acc_write_reg(ACC_INT1_DURATION, &id, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_fifo_mode_enable
* Description    : Sets Fifo Modality
* Input          : ACC_FIFO_DISABLE, ACC_FIFO_BYPASS_MODE, ACC_FIFO_MODE,
                   ACC_FIFO_STREAM_MODE, ACC_FIFO_TRIGGER_MODE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_fifo_mode_enable(acc_fifo_mode_t fm)
{
    uint8 value;

    if(fm == ACC_FIFO_DISABLE) {
        if( !hal_acc_read_reg(ACC_FIFO_CTRL_REG, &value, 1) )
            return MEMS_ERROR;

        value &= 0x1F;
        value |= (ACC_FIFO_BYPASS_MODE<<ACC_FM);

        if( !hal_acc_write_reg(ACC_FIFO_CTRL_REG, &value, 1) )           //fifo mode bypass
            return MEMS_ERROR;
        if( !hal_acc_read_reg(ACC_CTRL_REG5, &value, 1) )
            return MEMS_ERROR;

        value &= 0xBF;

        if( !hal_acc_write_reg(ACC_CTRL_REG5, &value, 1) )               //fifo disable
            return MEMS_ERROR;
    } else {   //ACC_FIFO_BYPASS_MODE, ACC_FIFO_MODE, ACC_FIFO_STREAM_MODE, ACC_FIFO_TRIGGER_MODE
        if( !hal_acc_read_reg(ACC_CTRL_REG5, &value, 1) )
            return MEMS_ERROR;

        value &= 0xBF;
        value |= MEMS_SET<<ACC_FIFO_EN;

        if( !hal_acc_write_reg(ACC_CTRL_REG5, &value, 1) )               //fifo enable
            return MEMS_ERROR;
        if( !hal_acc_read_reg(ACC_FIFO_CTRL_REG, &value, 1) )
            return MEMS_ERROR;

        value &= 0x1f;
        value |= (fm<<ACC_FM);                     //fifo mode configuration

        if( !hal_acc_write_reg(ACC_FIFO_CTRL_REG, &value, 1) )
            return MEMS_ERROR;
    }

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_trigger_int
* Description    : Trigger event liked to trigger signal INT1/INT2
* Input          : ACC_TRIG_INT1/ACC_TRIG_INT2
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_trigger_int(acc_trig_int_t tr)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_FIFO_CTRL_REG, &value, 1) )
        return MEMS_ERROR;

    value &= 0xDF;
    value |= (tr<<ACC_TR);

    if( !hal_acc_write_reg(ACC_FIFO_CTRL_REG, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_water_mark
* Description    : Sets Watermark Value
* Input          : Watermark = [0,31]
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_water_mark(uint8 wtm)
{
    uint8 value;

    if(wtm > 31)
        return MEMS_ERROR;

    if( !hal_acc_read_reg(ACC_FIFO_CTRL_REG, &value, 1) )
        return MEMS_ERROR;

    value &= 0xE0;
    value |= wtm;

    if( !hal_acc_write_reg(ACC_FIFO_CTRL_REG, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_status_reg
* Description    : Read the status register
* Input          : char to empty by Status Reg Value
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_status_reg(uint8* val)
{
    if( !hal_acc_read_reg(ACC_STATUS_REG, val, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_status_bit
* Description    : Read the status register BIT
* Input          : ACC_STATUS_REG_ZYXOR, ACC_STATUS_REG_ZOR, ACC_STATUS_REG_YOR, ACC_STATUS_REG_XOR,
                   ACC_STATUS_REG_ZYXDA, ACC_STATUS_REG_ZDA, ACC_STATUS_REG_YDA, ACC_STATUS_REG_XDA,
                   ACC_DATAREADY_BIT
                   val: Byte to be filled with the status bit
* Output         : status register BIT
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_status_bit(uint8 status_bit, uint8* val)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_STATUS_REG, &value, 1) )
        return MEMS_ERROR;

    if(value &= status_bit) {
        *val = MEMS_SET;
    } else {
        *val = MEMS_RESET;
    }

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_int1_src
* Description    : Reset Interrupt 1 Latching function
* Input          : Char to empty by Int1 source value
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_int1_src(uint8* val)
{

    if( !hal_acc_read_reg(ACC_INT1_SRC, val, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_int1_src_bit
* Description    : Reset Interrupt 1 Latching function
* Input          : statusBIT: ACC_INT1_SRC_IA, ACC_INT1_SRC_ZH, ACC_INT1_SRC_ZL.....
*                  val: Byte to be filled with the status bit
* Output         : None
* Return         : Status of BIT [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_int1_src_bit(uint8 status_bit, uint8* val)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_INT1_SRC, &value, 1) )
        return MEMS_ERROR;

    if(value &= status_bit) {
        *val = MEMS_SET;
    } else {
        *val = MEMS_RESET;
    }
    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_fifo_source_reg
* Description    : Read Fifo source Register
* Input          : Byte to empty by FIFO source register value
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_fifo_source_reg(uint8* val)
{

    if( !hal_acc_read_reg(ACC_FIFO_SRC_REG, val, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_get_fifo_source_bit
* Description    : Read Fifo WaterMark source bit
* Input          : statusBIT: ACC_FIFO_SRC_WTM, ACC_FIFO_SRC_OVRUN, ACC_FIFO_SRC_EMPTY
*                  val: Byte to fill  with the bit value
* Output         : None
* Return         : Status of BIT [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_get_fifo_source_bit(uint8 status_bit,  uint8* val)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_FIFO_SRC_REG, &value, 1) )
        return MEMS_ERROR;

    if(value &= status_bit) {
        *val = MEMS_SET;
    } else {
        *val = MEMS_RESET;
    }
    return MEMS_SUCCESS;
}


/*******************************************************************************
* Function Name  : hal_acc_set_spi_interface
* Description    : Set SPI mode: 3 Wire Interface OR 4 Wire Interface
* Input          : ACC_SPI_3_WIRE, ACC_SPI_4_WIRE
* Output         : None
* Return         : Status [MEMS_ERROR, MEMS_SUCCESS]
*******************************************************************************/
status_t hal_acc_set_spi_interface(acc_spi_mode_t spi)
{
    uint8 value;

    if( !hal_acc_read_reg(ACC_CTRL_REG4, &value, 1) )
        return MEMS_ERROR;

    value &= 0xFE;
    value |= spi<<ACC_SIM;

    if( !hal_acc_write_reg(ACC_CTRL_REG4, &value, 1) )
        return MEMS_ERROR;

    return MEMS_SUCCESS;
}





/**************************************************************************************************
* @fn          HalAccSelect
*
* @brief       Select the accelerometer on the I2C-bus
*
* @return
*/
static void hal_acc_select(void)
{
    //Set up I2C that is used to communicate with LIS3DH
    HalI2CInit(HAL_LIS3DH_I2C_ADDRESS, i2cClock_267KHZ);
}

/**************************************************************************************************
* @fn          hal_acc_init
*
* @brief       This function initializes the HAL Accelerometer abstraction layer.
*
* @return      None.
*/
void hal_acc_init(void)
{
	// Select this sensor
    hal_acc_select();
    hal_acc_set_full_scale(ACC_FULLSCALE_16);
}


/**************************************************************************************************
* @fn          hal_acc_read
*
* @brief       Read data from the accelerometer - X, Y, Z - 6 bytes
*
* @return      TRUE if valid data, FALSE if not
*/
bool hal_acc_read(uint8 *pBuf )
{
    bool success;

    hal_acc_set_mode(ACC_LOW_POWER);
    // hal_acc_set_mode will help to recover the scale setting value
    // after recover from power_down mode
    //hal_acc_set_full_scale(ACC_FULLSCALE_16);

    // Wait for measurement ready (appx. 1.45 ms)
    // typical turn-on time for LIS3DH with ODR as 100Hz is 1ms
    ST_HAL_DELAY(180);

    ///TODO: may need change to FIFO mode later
    // Read the three registers
    success = hal_acc_read_reg(ACC_OUT_X_L, pBuf, 6);

    hal_acc_set_mode(ACC_POWER_DOWN);

    return success;
}



