/******************************************************************************

 @file  hal_acc.c

 @brief Driver for the Kionix KXTI9 Accelerometer.

 Group: WCS, BTS
 Target Device: CC2540, CC2541

 ******************************************************************************
 
 Copyright (c) 2012-2016, Texas Instruments Incorporated
 All rights reserved.

 IMPORTANT: Your use of this Software is limited to those specific rights
 granted under the terms of a software license agreement between the user
 who downloaded the software, his/her employer (which must be your employer)
 and Texas Instruments Incorporated (the "License"). You may not use this
 Software unless you agree to abide by the terms of the License. The License
 limits your use, and you acknowledge, that the Software may not be modified,
 copied or distributed unless embedded on a Texas Instruments microcontroller
 or used solely and exclusively in conjunction with a Texas Instruments radio
 frequency transceiver, which is integrated into your product. Other than for
 the foregoing purpose, you may not use, reproduce, copy, prepare derivative
 works of, modify, distribute, perform, display or sell this Software and/or
 its documentation for any purpose.

 YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
 PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
 NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
 TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
 NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
 LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
 INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
 OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
 OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
 (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

 Should you have any questions regarding your right to use this Software,
 contact Texas Instruments Incorporated at www.TI.com.

 ******************************************************************************
 Release Name: ble_sdk_1.4.2.2
 Release Date: 2016-06-09 06:57:09
 *****************************************************************************/

/* ------------------------------------------------------------------------------------------------
*                                          Includes
* ------------------------------------------------------------------------------------------------
*/

#include "hal_acc_stm.h"
#include "hal_sensor.h"
#include "hal_i2c.h"
#include "hal_board_cfg.h"

/* ------------------------------------------------------------------------------------------------
*                                           Constants
* ------------------------------------------------------------------------------------------------
*/
// Sensor I2C address
#define HAL_LIS3DH_I2C_ADDRESS          0x18

// LIS3DH register addresses
#define ACC_REG_STATUS_REG_AUX          0x07 // R
#define ACC_REG_OUT_ADC1_L              0x08 // R
#define ACC_REG_OUT_ADC1_H              0x09 // R
#define ACC_REG_OUT_ADC2_L              0x0A // R
#define ACC_REG_OUT_ADC2_H              0x0B // R
#define ACC_REG_OUT_ADC3_L              0x0C // R
#define ACC_REG_OUT_ADC3_H              0x0D // R
#define ACC_REG_INT_COUNTER_REG         0x0E // R

#define ACC_REG_TEMP_CFG_REG            0x1F // R/W
#define ACC_REG_CTRL_REG1               0x20 // R/W
#define ACC_REG_CTRL_REG2               0x21 // R/W
#define ACC_REG_CTRL_REG3               0x22 // R/W
#define ACC_REG_CTRL_REG4               0x23 // R/W
#define ACC_REG_CTRL_REG5               0x24 // R/W
#define ACC_REG_CTRL_REG6               0x25 // R/W
#define ACC_REG_REFERENCE              0x26 // R/W

#define ACC_REG_STATUS_REG2          0x27 // R
#define ACC_REG_OUT_X_L                     0x28 // R
#define ACC_REG_OUT_X_H                    0x29 // R
#define ACC_REG_OUT_Y_L                     0x2A // R
#define ACC_REG_OUT_Y_H                     0x2B // R
#define ACC_REG_OUT_Z_L                     0x2C // R
#define ACC_REG_OUT_Z_H                    0x2D // R

#define ACC_REG_FIFO_CTRL_REG      0x2E // R/W
#define ACC_REG_FIFO_SRC_REG        0x2F // R

#define ACC_REG_INT1_CFG                    0x30 // R/W
#define ACC_REG_INT1_SOURCE           0x31 // R
#define ACC_REG_INT1_THS                    0x32 // R/W
#define ACC_REG_INT1_DURATION       0x33 // R/W

#define ACC_REG_CLICK_CFG                 0x38 // R/W
#define ACC_REG_CLICK_SRC                 0x39 // R
#define ACC_REG_CLICK_THS                 0x3A // R/W

#define ACC_REG_TIME_LIMIT                 0x3B // R/W
#define ACC_REG_TIME_LATENCY         0x3C // R/W
#define ACC_REG_TIME_WINDOW          0x3D // R/W


// CTRL1 BIT MASKS
#define ACC_REG_CTRL_PC                0x80 // Power control  '1' On    '0' Off
#define ACC_REG_CTRL_RES               0x40 // Resolution     '1' High  '0' Low
#define ACC_REG_CTRL_DRDYE             0x20 // Data Ready     '1' On    '0' Off
#define ACC_REG_CTRL_GSEL_HI           0x10 // Range     '00' +/-2g    '01' +/-4g
#define ACC_REG_CTRL_GSEL_LO           0x08 //           '10' +/-8g    '11' N/A
#define ACC_REG_CTRL_GSEL_TDTE         0x04 // Directional Tap '1' On   '0' Off
#define ACC_REG_CTRL_GSEL_WUFE         0x02 // Wake Up         '1' On   '0' Off
#define ACC_REG_CTRL_GSEL_TPE          0x01 // Tilt Position   '1' On   '0' Off

// Range +- 2G
#define ACC_REG_CTRL_ON_2G             ( ACC_REG_CTRL_PC )
#define ACC_REG_CTRL_OFF_2G            ( 0 )

// Range +- 4G
#define ACC_REG_CTRL_ON_4G             ( ACC_REG_CTRL_PC | ACC_REG_CTRL_GSEL_LO)
#define ACC_REG_CTRL_OFF_4G            ( ACC_REG_CTRL_GSEL_LO )

// Range +- 8G
#define ACC_REG_CTRL_ON_8G             ( ACC_REG_CTRL_PC | ACC_REG_CTRL_GSEL_HI)
#define ACC_REG_CTRL_OFF_8G            ( ACC_REG_CTRL_GSEL_HI)

/* ------------------------------------------------------------------------------------------------
*                                           Typedefs
* ------------------------------------------------------------------------------------------------
*/

/* ------------------------------------------------------------------------------------------------
*                                           Macros
* ------------------------------------------------------------------------------------------------
*/

/* ------------------------------------------------------------------------------------------------
*                                           Local Functions
* ------------------------------------------------------------------------------------------------
*/
static void HalAccSelect(void);

/* ------------------------------------------------------------------------------------------------
*                                           Local Variables
* ------------------------------------------------------------------------------------------------
*/
static uint8 accSensorConfig;
static uint8 accSensorOff;
static uint8 accRange;

/**************************************************************************************************
* @fn          HalAccInit
*
* @brief       This function initializes the HAL Accelerometer abstraction layer.
*
* @return      None.
*/
void HalAccInit(void)
{
  HalAccSetRange(HAL_ACC_RANGE_8G);
}

/**************************************************************************************************
* @fn          HalAccSetRange
*
* @brief       Set the range of the accelerometer
*
* @param       range: HAL_ACC_RANGE_2G, HAL_ACC_RANGE_4G, HAL_ACC_RANGE_8G
*
* @return      None
*/
void HalAccSetRange(uint8 range)
{
  accRange = range;
  
  switch (accRange)
  {
  case HAL_ACC_RANGE_2G:
    accSensorConfig = ACC_REG_CTRL_ON_2G;
    accSensorOff = ACC_REG_CTRL_OFF_2G;
    break;
  case HAL_ACC_RANGE_4G:
    accSensorConfig = ACC_REG_CTRL_ON_4G;
    accSensorOff = ACC_REG_CTRL_OFF_4G;
    break;
  case HAL_ACC_RANGE_8G:
    accSensorConfig = ACC_REG_CTRL_ON_8G;
    accSensorOff = ACC_REG_CTRL_OFF_8G;
    break;
  default:
    // Should not get here
    break;
  }
}

/**************************************************************************************************
* @fn          HalAccRead
*
* @brief       Read data from the accelerometer - X, Y, Z - 3 bytes
*
* @return      TRUE if valid data, FALSE if not
*/
bool HalAccRead(uint8 *pBuf )
{
  uint8 x;
  uint8 y;
  uint8 z;
  bool success;

  // Select this sensor
  HalAccSelect();

  // Turn on sensor
  HalSensorWriteReg(ACC_REG_ADDR_CTRL_REG1, &accSensorConfig, sizeof(accSensorConfig));

  // Wait for measurement ready (appx. 1.45 ms)
  ST_HAL_DELAY(180);

  // Read the three registers
  success = HalSensorReadReg( ACC_REG_ADDR_XOUT_H, &x, sizeof(x));
  if (success)
  {
    success = HalSensorReadReg( ACC_REG_ADDR_YOUT_H, &y, sizeof(y));
    if (success)
    {
       success = HalSensorReadReg( ACC_REG_ADDR_ZOUT_H, &z, sizeof(z));
    }
  }

  if (success)
  {
    // Valid data
    pBuf[0] = x;
    pBuf[1] = y;
    pBuf[2] = z;
  }

  // Turn off sensor 
  HalSensorWriteReg(ACC_REG_ADDR_CTRL_REG1, &accSensorOff, sizeof(accSensorOff));

  return success;
}


/**************************************************************************************************
 * @fn          HalAccTest
 *
 * @brief       Run a sensor self-test
 *
 * @return      TRUE if passed, FALSE if failed
 */
bool HalAccTest(void)
{
  uint8 val;

  // Select this sensor on the I2C bus
  HalAccSelect();

  // Check the DCST_RESP (pattern 0x55)
  ST_ASSERT(HalSensorReadReg(ACC_REG_ADDR_DCST_RESP, &val, 1));
  ST_ASSERT(val==0x55);

  // Check the DCST_RESP (pattern 0xAA)
  val = 0x10;     // Sets the DCST bit
  ST_ASSERT(HalSensorWriteReg(ACC_REG_ADDR_CTRL_REG3, &val, 1));
  ST_ASSERT(HalSensorReadReg(ACC_REG_ADDR_DCST_RESP, &val, 1));
  ST_ASSERT(val==0xAA);

  // Check the WHO AM I register
  ST_ASSERT(HalSensorReadReg(ACC_REG_ADDR_WHO_AM_I, &val, 1));
  ST_ASSERT(val==REG_VAL_WHO_AM_I);

  return TRUE;
}

/* ------------------------------------------------------------------------------------------------
*                                           Private functions
* -------------------------------------------------------------------------------------------------
*/

/**************************************************************************************************
* @fn          HalAccSelect
*
* @brief       Select the accelerometer on the I2C-bus
*
* @return
*/
static void HalAccSelect(void)
{
  //Set up I2C that is used to communicate with SHT21
  HalI2CInit(HAL_KXTI9_I2C_ADDRESS,i2cClock_267KHZ);
}

/*  Conversion algorithm for X, Y, Z
 *  ================================
 *
float calcAccel(int8 rawX, uint8 range)
{
    float v;

    switch (range)
    {
      case HAL_ACC_RANGE_2G:
      //-- calculate acceleration, unit G, range -2, +2
      v = (rawX * 1.0) / (256/4);
      break;

      case HAL_ACC_RANGE_4G:
      //-- calculate acceleration, unit G, range -4, +4
      v = (rawX * 1.0) / (256/8);
      break;

      case HAL_ACC_RANGE_4G:
      //-- calculate acceleration, unit G, range -8, +8
      v = (rawX * 1.0) / (256/16);
      break;    
    }
    return v;
}
*/

/*********************************************************************
*********************************************************************/
