/******************************************************************************

 @file  hal_acc_stm.h

 @brief This file contains the declaration to the HAL LIS3DH abstraction layer.

 Target Device: CC2541

 *****************************************************************************/
#ifndef HAL_ACC_STM_H
#define HAL_ACC_STM_H

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------------------------------------
 *                                          Includes
 * ------------------------------------------------------------------------------------------------
 */

#include "comdef.h"

/* ------------------------------------------------------------------------------------------------
 *                                          Constants
 * ------------------------------------------------------------------------------------------------
 */
/* SA0 connect to power to avoid extra 150uA power comsumption */
#define HAL_LIS3DH_I2C_ADDRESS          0x19  


#define ValBit(VAR,Place)                           (VAR & (1<<Place))
#define BIT(x)                                      ( (x) )

#define MEMS_SET                                    0x01
#define MEMS_RESET                                  0x00

//Register Definition
#define ACC_WHO_AM_I                                0x0F

// CONTROL REGISTER 1
#define ACC_CTRL_REG1                               0x20
#define ACC_ODR_BIT                                 BIT(4)
#define ACC_LPEN                                    BIT(3)
#define ACC_ZEN                                     BIT(2)
#define ACC_YEN                                     BIT(1)
#define ACC_XEN                                     BIT(0)

//CONTROL REGISTER 2
#define ACC_CTRL_REG2                               0x21
#define ACC_HPM                                     BIT(6)
#define ACC_HPCF                                    BIT(4)
#define ACC_FDS                                     BIT(3)
#define ACC_HPCLICK                                 BIT(2)
#define ACC_HPIS2                                   BIT(1)
#define ACC_HPIS1                                   BIT(0)

//CONTROL REGISTER 3
#define ACC_CTRL_REG3                               0x22
#define ACC_I1_CLICK                                BIT(7)
#define ACC_I1_AOI1                                 BIT(6)
#define ACC_I1_AOI2                                 BIT(5)
#define ACC_I1_DRDY1                                BIT(4)
#define ACC_I1_DRDY2                                BIT(3)
#define ACC_I1_WTM                                  BIT(2)
#define ACC_I1_ORUN                                 BIT(1)

//CONTROL REGISTER 6
#define ACC_CTRL_REG6                               0x25
#define ACC_I2_CLICK                                BIT(7)
#define ACC_I2_INT1                                 BIT(6)
#define ACC_I2_BOOT                                 BIT(4)
#define ACC_H_LACTIVE                               BIT(1)

//TEMPERATURE CONFIG REGISTER
#define ACC_TEMP_CFG_REG                            0x1F
#define ACC_ADC_PD                                  BIT(7)
#define ACC_TEMP_EN                                 BIT(6)

//CONTROL REGISTER 4
#define ACC_CTRL_REG4                               0x23
#define ACC_BDU                                     BIT(7)
#define ACC_BLE                                     BIT(6)
#define ACC_FS                                      BIT(4)
#define ACC_HR                                      BIT(3)
#define ACC_ST                                      BIT(1)
#define ACC_SIM                                     BIT(0)

//CONTROL REGISTER 5
#define ACC_CTRL_REG5                               0x24
#define ACC_BOOT                                    BIT(7)
#define ACC_FIFO_EN                                 BIT(6)
#define ACC_LIR_INT1                                BIT(3)
#define ACC_D4D_INT1                                BIT(2)

//REFERENCE/DATA_CAPTURE
#define ACC_REFERENCE_REG                           0x26
#define ACC_REF                                     BIT(0)

//STATUS_REG_AXIES
#define ACC_STATUS_REG                              0x27
#define ACC_ZYXOR                                   BIT(7)
#define ACC_ZOR                                     BIT(6)
#define ACC_YOR                                     BIT(5)
#define ACC_XOR                                     BIT(4)
#define ACC_ZYXDA                                   BIT(3)
#define ACC_ZDA                                     BIT(2)
#define ACC_YDA                                     BIT(1)
#define ACC_XDA                                     BIT(0)

//STATUS_REG_AUX
#define ACC_STATUS_AUX                              0x07

//INTERRUPT 1 CONFIGURATION
#define ACC_INT1_CFG                                0x30
#define ACC_ANDOR                                   BIT(7)
#define ACC_INT_6D                                  BIT(6)
#define ACC_ZHIE                                    BIT(5)
#define ACC_ZLIE                                    BIT(4)
#define ACC_YHIE                                    BIT(3)
#define ACC_YLIE                                    BIT(2)
#define ACC_XHIE                                    BIT(1)
#define ACC_XLIE                                    BIT(0)

//FIFO CONTROL REGISTER
#define ACC_FIFO_CTRL_REG                           0x2E
#define ACC_FM                                      BIT(6)
#define ACC_TR                                      BIT(5)
#define ACC_FTH                                     BIT(0)

//CONTROL REG3 bit mask
#define ACC_CLICK_ON_PIN_INT1_ENABLE                0x80
#define ACC_CLICK_ON_PIN_INT1_DISABLE               0x00
#define ACC_I1_INT1_ON_PIN_INT1_ENABLE              0x40
#define ACC_I1_INT1_ON_PIN_INT1_DISABLE             0x00
#define ACC_I1_INT2_ON_PIN_INT1_ENABLE              0x20
#define ACC_I1_INT2_ON_PIN_INT1_DISABLE             0x00
#define ACC_I1_DRDY1_ON_INT1_ENABLE                 0x10
#define ACC_I1_DRDY1_ON_INT1_DISABLE                0x00
#define ACC_I1_DRDY2_ON_INT1_ENABLE                 0x08
#define ACC_I1_DRDY2_ON_INT1_DISABLE                0x00
#define ACC_WTM_ON_INT1_ENABLE                      0x04
#define ACC_WTM_ON_INT1_DISABLE                     0x00
#define ACC_INT1_OVERRUN_ENABLE                     0x02
#define ACC_INT1_OVERRUN_DISABLE                    0x00

//CONTROL REG6 bit mask
#define ACC_CLICK_ON_PIN_INT2_ENABLE                0x80
#define ACC_CLICK_ON_PIN_INT2_DISABLE               0x00
#define ACC_I2_INT1_ON_PIN_INT2_ENABLE              0x40
#define ACC_I2_INT1_ON_PIN_INT2_DISABLE             0x00
#define ACC_I2_INT2_ON_PIN_INT2_ENABLE              0x20
#define ACC_I2_INT2_ON_PIN_INT2_DISABLE             0x00
#define ACC_I2_BOOT_ON_INT2_ENABLE                  0x10
#define ACC_I2_BOOT_ON_INT2_DISABLE                 0x00
#define ACC_INT_ACTIVE_HIGH                         0x00
#define ACC_INT_ACTIVE_LOW                          0x02

//INT1_CFG bit mask
#define ACC_INT1_AND                                0x80
#define ACC_INT1_OR                                 0x00
#define ACC_INT1_ZHIE_ENABLE                        0x20
#define ACC_INT1_ZHIE_DISABLE                       0x00
#define ACC_INT1_ZLIE_ENABLE                        0x10
#define ACC_INT1_ZLIE_DISABLE                       0x00
#define ACC_INT1_YHIE_ENABLE                        0x08
#define ACC_INT1_YHIE_DISABLE                       0x00
#define ACC_INT1_YLIE_ENABLE                        0x04
#define ACC_INT1_YLIE_DISABLE                       0x00
#define ACC_INT1_XHIE_ENABLE                        0x02
#define ACC_INT1_XHIE_DISABLE                       0x00
#define ACC_INT1_XLIE_ENABLE                        0x01
#define ACC_INT1_XLIE_DISABLE                       0x00

//INT1_SRC bit mask
#define ACC_INT1_SRC_IA                             0x40
#define ACC_INT1_SRC_ZH                             0x20
#define ACC_INT1_SRC_ZL                             0x10
#define ACC_INT1_SRC_YH                             0x08
#define ACC_INT1_SRC_YL                             0x04
#define ACC_INT1_SRC_XH                             0x02
#define ACC_INT1_SRC_XL                             0x01

//INT1 REGISTERS
#define ACC_INT1_THS                                0x32
#define ACC_INT1_DURATION                           0x33

//INTERRUPT 1 SOURCE REGISTER
#define ACC_INT1_SRC                                0x31

//FIFO Source Register bit Mask
#define ACC_FIFO_SRC_WTM                            0x80
#define ACC_FIFO_SRC_OVRUN                          0x40
#define ACC_FIFO_SRC_EMPTY                          0x20

//INTERRUPT CLICK REGISTER
#define ACC_CLICK_CFG                               0x38
//INTERRUPT CLICK CONFIGURATION bit mask
#define ACC_ZD_ENABLE                               0x20
#define ACC_ZD_DISABLE                              0x00
#define ACC_ZS_ENABLE                               0x10
#define ACC_ZS_DISABLE                              0x00
#define ACC_YD_ENABLE                               0x08
#define ACC_YD_DISABLE                              0x00
#define ACC_YS_ENABLE                               0x04
#define ACC_YS_DISABLE                              0x00
#define ACC_XD_ENABLE                               0x02
#define ACC_XD_DISABLE                              0x00
#define ACC_XS_ENABLE                               0x01
#define ACC_XS_DISABLE                              0x00

//INTERRUPT CLICK SOURCE REGISTER
#define ACC_CLICK_SRC                               0x39
//INTERRUPT CLICK SOURCE REGISTER bit mask
#define ACC_IA                                      0x40
#define ACC_DCLICK                                  0x20
#define ACC_SCLICK                                  0x10
#define ACC_CLICK_SIGN                              0x08
#define ACC_CLICK_Z                                 0x04
#define ACC_CLICK_Y                                 0x02
#define ACC_CLICK_X                                 0x01

//Click-click Register
#define ACC_CLICK_THS                               0x3A
#define ACC_TIME_LIMIT                              0x3B
#define ACC_TIME_LATENCY                            0x3C
#define ACC_TIME_WINDOW                             0x3D

//OUTPUT REGISTER
#define ACC_OUT_X_L                                 0x28
#define ACC_OUT_X_H                                 0x29
#define ACC_OUT_Y_L                                 0x2A
#define ACC_OUT_Y_H                                 0x2B
#define ACC_OUT_Z_L                                 0x2C
#define ACC_OUT_Z_H                                 0x2D

//AUX REGISTER
#define ACC_OUT_1_L                                 0x08
#define ACC_OUT_1_H                                 0x09
#define ACC_OUT_2_L                                 0x0A
#define ACC_OUT_2_H                                 0x0B
#define ACC_OUT_3_L                                 0x0C
#define ACC_OUT_3_H                                 0x0D

//STATUS REGISTER bit mask
#define ACC_STATUS_REG_ZYXOR                        0x80    // 1 :   new data set has over written the previous one
// 0    :   no overrun has occurred (default)
#define ACC_STATUS_REG_ZOR                          0x40    // 0 :   no overrun has occurred (default)
// 1    :   new Z-axis data has over written the previous one
#define ACC_STATUS_REG_YOR                          0x20    // 0 :   no overrun has occurred (default)
// 1    :   new Y-axis data has over written the previous one
#define ACC_STATUS_REG_XOR                          0x10    // 0 :   no overrun has occurred (default)
// 1    :   new X-axis data has over written the previous one
#define ACC_STATUS_REG_ZYXDA                        0x08    // 0 :   a new set of data is not yet avvious one
// 1    :   a new set of data is available
#define ACC_STATUS_REG_ZDA                          0x04    // 0 :   a new data for the Z-Axis is not availvious one
// 1    :   a new data for the Z-Axis is available
#define ACC_STATUS_REG_YDA                          0x02    // 0 :   a new data for the Y-Axis is not available
// 1    :   a new data for the Y-Axis is available
#define ACC_STATUS_REG_XDA                          0x01    // 0 :   a new data for the X-Axis is not available

#define ACC_DATAREADY_BIT                           ACC_STATUS_REG_ZYXDA

//STATUS AUX REGISTER bit mask
#define ACC_STATUS_AUX_321OR                        0x80
#define ACC_STATUS_AUX_3OR                          0x40
#define ACC_STATUS_AUX_2OR                          0x20
#define ACC_STATUS_AUX_1OR                          0x10
#define ACC_STATUS_AUX_321DA                        0x08
#define ACC_STATUS_AUX_3DA                          0x04
#define ACC_STATUS_AUX_2DA                          0x02
#define ACC_STATUS_AUX_1DA                          0x01

#define ACC_MEMS_I2C_ADDRESS                        0x33

//FIFO REGISTERS
#define ACC_FIFO_CTRL_REG                           0x2E
#define ACC_FIFO_SRC_REG                            0x2F

/* ------------------------------------------------------------------------------------------------
*                                           Typedefs
* ------------------------------------------------------------------------------------------------
*/

typedef enum {
    MEMS_SUCCESS                =       0x01,
    MEMS_ERROR                  =       0x00
} status_t;

typedef enum {
    MEMS_ENABLE                 =       0x01,
    MEMS_DISABLE                =       0x00
} state_t;

typedef struct {
    int16 AXIS_X;
    int16 AXIS_Y;
    int16 AXIS_Z;
} axes_raw_t;

typedef enum {
    ACC_ODR_1Hz                 =       0x01,
    ACC_ODR_10Hz                =       0x02,
    ACC_ODR_25Hz                =       0x03,
    ACC_ODR_50Hz                =       0x04,
    ACC_ODR_100Hz               =       0x05,
    ACC_ODR_200Hz               =       0x06,
    ACC_ODR_400Hz               =       0x07,
    ACC_ODR_1620Hz_LP           =       0x08,
    ACC_ODR_1250Hz_NP_5000HZ_LP =       0x09
} acc_odr_t;

typedef enum {
    ACC_POWER_DOWN              =       0x00,
    ACC_LOW_POWER               =       0x01,
    ACC_NORMAL                  =       0x02
} acc_mode_t;

typedef enum {
    ACC_HPM_NORMAL_MODE_RES     =       0x00,
    ACC_HPM_REF_SIGNAL          =       0x01,
    ACC_HPM_NORMAL_MODE         =       0x02,
    ACC_HPM_AUTORESET_INT       =       0x03
} acc_hpf_mode_t;

typedef enum {
    ACC_HPFCF_0                 =        0x00,
    ACC_HPFCF_1                 =        0x01,
    ACC_HPFCF_2                 =        0x02,
    ACC_HPFCF_3                 =        0x03
} acc_hpf_cut_off_freq_t;

typedef struct {
    uint16 AUX_1;
    uint16 AUX_2;
    uint16 AUX_3;
} acc_aux_123_raw_t;

typedef enum {
    ACC_FULLSCALE_2             =        0x00,
    ACC_FULLSCALE_4             =        0x01,
    ACC_FULLSCALE_8             =        0x02,
    ACC_FULLSCALE_16            =        0x03
} acc_full_scale_t;

typedef enum {
    ACC_BLE_LSB                 =        0x00,
    ACC_BLE_MSB                 =        0x01
} acc_endianess_t;

typedef enum {
    ACC_SELF_TEST_DISABLE       =        0x00,
    ACC_SELF_TEST_0             =        0x01,
    ACC_SELF_TEST_1             =        0x02
} acc_self_test_t;

typedef enum {
    ACC_FIFO_BYPASS_MODE        =        0x00,
    ACC_FIFO_MODE               =        0x01,
    ACC_FIFO_STREAM_MODE        =        0x02,
    ACC_FIFO_TRIGGER_MODE       =        0x03,
    ACC_FIFO_DISABLE            =        0x04
} acc_fifo_mode_t;

typedef enum {
    ACC_TRIG_INT1               =        0x00,
    ACC_TRIG_INT2               =        0x01
} acc_trig_int_t;

// seems to be not used

typedef enum {
    ACC_SPI_4_WIRE              =        0x00,
    ACC_SPI_3_WIRE              =        0x01
} acc_spi_mode_t;

typedef enum {
    ACC_X_ENABLE                =        0x01,
    ACC_X_DISABLE               =        0x00,
    ACC_Y_ENABLE                =        0x02,
    ACC_Y_DISABLE               =        0x00,
    ACC_Z_ENABLE                =        0x04,
    ACC_Z_DISABLE               =        0x00
} acc_axis_enable_t;

typedef enum {
    ACC_INT1_6D_4D_DISABLE      =        0x00,
    ACC_INT1_6D_ENABLE          =        0x01,
    ACC_INT1_4D_ENABLE          =        0x02
} acc_int_6d_4d_t;


typedef enum {
    ACC_UP_SX                   =        0x44,
    ACC_UP_DX                   =        0x42,
    ACC_DW_SX                   =        0x41,
    ACC_DW_DX                   =        0x48,
    ACC_TOP                     =        0x60,
    ACC_BOTTOM                  =        0x50
} acc_position_6d_t;

typedef enum {
    ACC_INT_MODE_OR             =        0x00,
    ACC_INT_MODE_6D_MOVEMENT    =        0x01,
    ACC_INT_MODE_AND            =        0x02,
    ACC_INT_MODE_6D_POSITION    =        0x03
} acc_int1_mode_t;


//interrupt click response
//  b7 = don't care   b6 = IA  b5 = DClick  b4 = Sclick  b3 = Sign
//  b2 = z      b1 = y     b0 = x
typedef enum {
    ACC_DCLICK_Z_P              =        0x24,
    ACC_DCLICK_Z_N              =        0x2C,
    ACC_SCLICK_Z_P              =        0x14,
    ACC_SCLICK_Z_N              =        0x1C,
    ACC_DCLICK_Y_P              =        0x22,
    ACC_DCLICK_Y_N              =        0x2A,
    ACC_SCLICK_Y_P              =        0x12,
    ACC_SCLICK_Y_N              =        0x1A,
    ACC_DCLICK_X_P              =        0x21,
    ACC_DCLICK_X_N              =        0x29,
    ACC_SCLICK_X_P              =        0x11,
    ACC_SCLICK_X_N              =        0x19,
    ACC_NO_CLICK                =        0x00
} acc_click_response_t;

typedef uint8 acc_int_pin_config_t;
typedef uint8 acc_axis_t;
typedef uint8 acc_int1_config_t;

/* ------------------------------------------------------------------------------------------------
 *                                          Functions
 * ------------------------------------------------------------------------------------------------
 */
void hal_acc_init(void);
bool HalAccRead(uint8 *pBuf);
bool HalAccTest(void);
void hal_acc_set_range(uint8 range);

///

/* Exported functions --------------------------------------------------------*/
//Sensor Configuration Functions
status_t hal_acc_set_odr(acc_odr_t ov);
status_t hal_acc_set_mode(acc_mode_t md);
status_t hal_acc_set_axis(acc_axis_t axis);
status_t hal_acc_set_full_scale(acc_full_scale_t fs);
status_t hal_acc_set_bdu(state_t bdu);
status_t hal_acc_set_ble(acc_endianess_t ble);
status_t hal_acc_set_self_test(acc_self_test_t st);
status_t hal_acc_set_temperature(state_t state);
status_t hal_acc_set_adcaux(state_t state);
status_t hal_acc_set_spi_interface(acc_spi_mode_t spi);

//Filtering Functions
status_t hal_acc_set_hpf_click(state_t hpfe);
status_t hal_acc_set_hpf_aoi1(state_t hpfe);
status_t hal_acc_set_hpf_aoi2(state_t hpfe);
status_t hal_acc_set_hpf_mode(acc_hpf_mode_t hpf);
status_t hal_acc_set_hpf_cut_off(acc_hpf_cut_off_freq_t hpf);
status_t hal_acc_set_filter_data_sel(state_t state);

//Interrupt Functions
status_t hal_acc_set_int1_pin(acc_int_pin_config_t pinConf);
status_t hal_acc_set_int2_pin(acc_int_pin_config_t pinConf);
status_t hal_acc_set_int1_latch(state_t latch);
status_t hal_acc_clear_int1_src(void);
status_t hal_acc_set_int_config(acc_int1_config_t ic);
status_t hal_acc_set_int1_threshold(uint8 ths);
status_t hal_acc_set_int1_duration(acc_int1_config_t id);
status_t hal_acc_set_int_mode(acc_int1_mode_t int_mode);
status_t hal_acc_set_click_config(uint8 status);
status_t hal_acc_set_click_threshold(uint8 ths);
status_t hal_acc_set_click_limit(uint8 t_limit);
status_t hal_acc_set_click_latency(uint8 t_latency);
status_t hal_acc_set_click_window(uint8 t_window);
status_t hal_acc_set_int_6d_4d_config(acc_int_6d_4d_t ic);
status_t hal_acc_get_int1_src(uint8* val);
status_t hal_acc_get_int1_src_bit(uint8 status_bit, uint8* val);

//FIFO Functions
status_t hal_acc_fifo_mode_enable(acc_fifo_mode_t fm);
status_t hal_acc_set_water_mark(uint8 wtm);
status_t hal_acc_set_trigger_int(acc_trig_int_t tr);
status_t hal_acc_get_fifo_source_reg(uint8* val);
status_t hal_acc_get_fifo_source_bit(uint8 status_bit, uint8* val);
status_t hal_acc_get_unread_sample_in_fifo(uint8* val);

//Other Reading Functions
status_t hal_acc_get_status_reg(uint8* val);
status_t hal_acc_get_status_bit(uint8 status_bit, uint8* val);
status_t hal_acc_get_status_aux_bit(uint8 status_bit, uint8* val);
status_t hal_acc_get_status_aux(uint8* val);
status_t hal_acc_get_axes_value(axes_raw_t* buff);
status_t hal_acc_get_aux_raw(acc_aux_123_raw_t* buff);
status_t hal_acc_get_click_response(uint8* val);
status_t hal_acc_get_who_am_i(uint8* val);
status_t hal_acc_get_6d_position(uint8* val);

//Generic
status_t hal_acc_write_reg(uint8 addr, uint8 *pBuf, uint8 nBytes);
status_t hal_acc_read_reg(uint8 addr, uint8 *pBuf, uint8 nBytes);


#ifdef __cplusplus
};
#endif

#endif

/**************************************************************************************************
*/
